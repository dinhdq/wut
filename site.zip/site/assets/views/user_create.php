<?php 

	if (ktk_check_token($token) != 0) {
		return;
	}

	$maker = new html_maker();

	$wuser = new my_user();
	$data  = array();
	$data['token'] = $token;
	$data['id']    = $uid;
	$data['name']  = $uname;

	$roles = $cat->roles_data();
	
	if ($wuser->user_id > 0) {
		$wuser->load_user($data);
	}
?>

<script>
	function tbwidth() {
		var dv = document.getElementById("dtbl");
		var dn = document.getElementById("inotes");		
		var sd = window.screen.width;
		if (sd < 1000) {
			dv.setAttribute("style", "padding: 6px 0px 6px 0px;");
			dn.rows = "5";
			dn.style.width = "100%";		
		}
	}
</script>

<form  action="user_create" method="post">
<div   id="dtbl" class="table" type="update"> 

<?php 

	$red = '(<font color="red">*</font>)';	

	$row_start = PHP_EOL.'<div class="row" type="update">';
	$row_end   = PHP_EOL.'</div>';
	
	$list_roles  = $cat->get_list('user-roles');
	$list_status = array('--','NN','XX');
	
	if ($errs != NULL && is_array($errs) && count($errs) > 0) {
		echo $row_start;
		echo '<div class="col-sm-3" type="alt" style="color: red; font-style: normal">'.tb_word('users.create','error').'!!!'.'</div>';
		$lines = '';	
		foreach ($errs as $err) {
			$lines = $lines.'<li>'.tb_word($err, 'error').'</li>';
		}
		echo '<div class="col-sm-9" type="td">'.$lines.'</div>';		
		echo $row_end;
	}
	
	echo $row_start;
	echo '<div class="col-sm-3" type="alt">'.tb_word('user-name').':'.$red.'</div>';
	echo '<div class="col-sm-9" type="td">'.$maker->input_field('uname', $wuser->user_name).'</div>';		
	echo $row_end;

	echo $row_start;
	echo '<div class="col-sm-3" type="alt">'.tb_word('password').':'.$red.'</div>';
	echo '<div class="col-sm-9" type="td">'.$maker->input_field('upassword', '', array('type'=>'password')).'</div>';		
	echo $row_end;

	echo $row_start;
	echo '<div class="col-sm-3" type="alt">'.tb_word('re-type').':'.$red.'</div>';
	echo '<div class="col-sm-9" type="td">'.$maker->input_field('uretype', '', array('type'=>'password')).'</div>';		
	echo $row_end;

	echo $row_start;
	echo '<div class="col-sm-3" type="alt">'.tb_word('full-name').':'.$red.'</div>';
	echo '<div class="col-sm-9" type="td">'.$maker->input_field('fullname', $wuser->full_name).'</div>';		
	echo $row_end;
	
	echo $row_start;
	echo '<div class="col-sm-3" type="alt">'.tb_word('email').':'.$red.'</div>';
	echo '<div class="col-sm-9" type="td">'.$maker->input_field('email', $wuser->email).'</div>';		
	echo $row_end;

	echo $row_start;
	echo '<div class="col-sm-3" type="odd">'.tb_word('user-type').':'.'</div>';
	echo '<div class="col-sm-9" type="odd">'.tb_title($wuser->user_type).'</div>';		
	echo $row_end;
    	
    $str  = '';
    $s1   = '';
	$s2   = ($user->role_check('admin.roles.users.change-type')) ? '' : ' disabled';
		
    foreach ($list_roles as $item) {
    	$check = '';
    	if ($item == $wuser->user_type) {
    		$check = 'checked';
    	}
    			
    	$str = $str.PHP_EOL.$s1.'<input type="radio" name="types[]" value="'.$item.'" '.$check.$s2.'>'.tb_title($item);
    	$s1  = '<br style="line-height: 27px">';
    }
    		
	echo $row_start;
	echo '<div class="col-sm-3" type="td" style="border-bottom: 0px"> </div>';
	echo '<div class="col-sm-9" type="td">'.$str.'</div>';		
	echo $row_end;

	echo $row_start;
	echo '<div class="col-sm-3" type="odd">'.tb_word('status-text').':'.'</div>';
	echo '<div class="col-sm-9" type="odd">'.tb_word('status-'.$wuser->status).'</div>';		
	echo $row_end;
	
	$s2  = ($user->role_check('admin.roles.users.activate')) ? '' : ' disabled';
	$str = '';
    $s1   = '';
    foreach ($list_status as $item) {
		$check = ($item == $wuser->status) ? 'checked' : '';
    	$str = $str.PHP_EOL.$s1.'<input type="radio" name="stts[]" value="'.$item.'" '.$check.$s2.'>'.tb_word('status-'.$item);
    	$s1  = '<br style="line-height: 27px">';
    }
	echo $row_start;
	echo '<div class="col-sm-3" type="td"> </div>';
	echo '<div class="col-sm-9" type="td">'.$str.'</div>';		
	echo $row_end;

	$text = '<textarea id="inotes" rows = "10" name="notes" style="width: 100%">'.$wuser->notes.'</textarea>';
	echo $row_start;
	echo '<div class="col-sm-3" type="alt">'.tb_word('remark').':'.'</div>';
	echo '<div class="col-sm-9" type="td">'.$text.'</div>';		
	echo $row_end;
	
	$str1 = '<input type="submit" class="submit" name="btnCreate" value="Create">';
	$str2 = '<input type="submit" class="submit" name="btnCancel" value="Cancel">';
	echo $str1.$str2;
?>
</div>
</form>
<script>
	tbwidth();
</script>