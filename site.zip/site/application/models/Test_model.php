<?php
class test_model extends CI_Model
{
    function __construct()
    {
    	$this->load->database();
        parent::__construct();
    }
    
    /*
     * Get shop by id
     */
    function get_test($id)
    {
        return $this->db->get_where('test',array('id'=>$id))->row_array();
    }

    function get_all_test()
    {
        return $this->db->get('test')->result_array();
    }

    function add_test($params)
    {
        $this->db->insert('test',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update test
     */
    function update_test($id,$params)
    {
        $this->db->where(array('id'=>$id));
        $this->db->update('test',$params);
    }
    
    /*
     * function to delete test
     */
    function delete_test($id)
    {
        $this->db->delete('test',array('id'=>$id));
    }


}
?>