<?php
function system_message($code) {
	if ($code == NULL) {
		return;
	}
	$c1 = new my_category();
	$c1->load_me(0, $code);
	if (!is_object($c1->row)) {
		return;
	}
	echo '<div>';
	//echo '<div><h3 type="red">' . $c1->row->title . '</h3></div>';
	$msg  = $c1->row->notes;
	$days = 30;
	$msg  = str_replace('((days))', (string) $days, $msg);
	echo '<pre class="message">'. $msg . '</pre>';
	echo '</div>';
	return; 
}

function show_profile($mem, $cat) {

	
 	$a1   = array('basic'=>'Basic', 'billing'=>'Billings');
 	$a2   = array();
 	$a2[] = array('label'=>'member-name',  'field'   =>'member_name', 'class'=>'odd');
 	$a2[] = array('label'=>'full-name',    'field'   =>'full_name');
 	$a2[] = array('label'=>'email',        'field'   =>'email');
 	$a2[] = array('label'=>'phone',        'field'   =>'phone');
 	$a2[] = array('label'=>'max-shops',    'field'   =>'max_shops');
 	$a2[] = array('label'=>'package',      'field'   =>'package');
 	$a2[] = array('label'=>'status-text',  'field'   =>'status', 'class'=>'odd');
 	$a2[] = array('label'=>'create-date',  'field'   =>'signup_date');
 	$a2[] = array('label'=>'active-date',  'field'   =>'active_date');
 	$a2[] = array('label'=>'expire-date',  'field'   =>'expire_date');
 	$a2[] = array('label'=>'last-update',  'field'   =>'last_update');
 	$a2[] = array('label'=>'last-user',    'field'   =>'last_user');
 	$a2[] = array('label'=>'supporter',    'field'   =>'supporter');
 	$a2[] = array('label'=>'agent-name',   'field'   =>'agent_name', 'class'=>'odd');

	//$a = array('menu'=>$a1, 'data'=>$a2);
	//echo json_encode($a); 	
 	 	
	$tbl = new my_table('member');
	$tbl->set_caption('');
	
	$tbl->remove_columns();
	$tbl->set_config('width',   '100%');
	$tbl->add_column($tbl->col_by_data('label|Label|25%|left|alt'));
	$tbl->add_column($tbl->col_by_data('data|Input:75%|left'));
		
	$tbl->header_off();
	$tbl->add_header();
	$tbl->set_defaults();
	
	foreach ($a2 as $a1) {
		$label = $a1['label'];
		$field = $a1['field'];
		$field = str_replace('((ST))', $mem->mydata['status'], $field);
		$text  = $field;
		if (array_key_exists($field, $mem->mydata)) {
			$text = ($field == 'status') ? tb_word('status-'.$mem->mydata[$field]) : $mem->mydata[$field];
		}
		$class = (array_key_exists('class', $a1)) ? $a1['class'] : 'td';
		$tbl->add_row(array(tb_word($label), $text), $class);	
	}
	$tbl->add_end();
	return;
}

?>
