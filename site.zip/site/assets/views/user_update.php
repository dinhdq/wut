
<?php 
	
	if (ktk_check_token($token) != 0) {
		return;
	}

	$maker = new html_maker();
    
    $class = 'admin';
	$wuser = new my_user();
	$data  = array();
	$data['token'] = $token;
	$data['id']    = $uid;
	$data['name']  = $uname;

	$roles = $cat->roles_data();
	
	$wuser->load_user($data);

    echo PHP_EOL.'<form action="'.tb_uri('update_profile').'" method="post">';
    echo PHP_EOL.'<input type="hidden" name="uid"     value="'.$wuser->user_id.'">';
    echo PHP_EOL.'<input type="hidden" name="uname"   value="'.$wuser->user_name.'">';
    echo PHP_EOL.'<input type="hidden" name="utype"   value="'.$wuser->user_type.'">';
    echo PHP_EOL.'<input type="hidden" name="ustatus" value="'.$wuser->status.'">';

?>

<div class="table" type="update">
	<div class="row" type="update">
		<div class="col-sm-3" type="alt"><?php echo tb_word('user-name').':'; ?></div>	
		<div class="col-sm-9" type="odd"><?php echo $wuser->user_name; ?></div>	
	</div>
	<div class="row" type="update">
		<div class="col-sm-3" type="alt"><?php echo tb_word('full-name').':'; ?></div>	
		<div class="col-sm-9" type="td"><?php echo $maker->input_field('fullname', $wuser->full_name); ?></div>	
	</div>
	<div class="row" type="update">
		<div class="col-sm-3" type="alt"><?php echo tb_word('email').':'; ?></div>	
		<div class="col-sm-9" type="td"><?php echo $maker->input_field('email', $wuser->email); ?></div>	
	</div>
	<div class="row" type="update">
		<div class="col-sm-3" type="alt"><?php echo tb_word('user-type').':'; ?></div>	
		<div class="col-sm-9" type="odd"><?php echo tb_title($wuser->user_type); ?></div>	
	</div>
</div>	

<?php
	
	$div_row  = PHP_EOL.'<div class="row" type="update">';
	$div_col1 = '<div class="col-sm-3" type="alt">';
	$div_col2 = '<div class="col-sm-9" type="td">';
	$div_col3 = '<div class="col-sm-9" type="odd">';
	
    $list = $cat->get_list('user-roles');
    $str  = '';
    $s1   = '';

    if (is_array($list) && $user->role_check('admin.roles.users.change-type')) {
    	foreach ($list as $item) {
    		$check = '';
    		if ($item == $wuser->user_type) {
    			$check = 'checked';
    		}
    		$str = $str.PHP_EOL.$s1.'<input type="radio" name="types[]" value="'.$item.'" '.$check.'>'.tb_title($item);
    		$s1  = '<br>';
    	}
		echo $div_row  . $div_col1 .' </div>';
		echo $div_col2 . $str . '</div></div>';		
    }
	
	$text = '<textarea id="inotes" rows = "10" name="notes" style="width: 100%">'.$wuser->notes.'</textarea>';
	
	echo $div_row  . $div_col1 . tb_word('remark') . ': </div>';
	echo $div_col2 . $text . '</div></div>';

	echo $div_row  . $div_col1 . tb_word('status-text') . ': </div>';
	echo $div_col3 . tb_word('status-'.$wuser->status) . '</div></div>';
	
	if (is_array($list) && $user->role_check('admin.roles.users.activate')) {
		$arr = array('--','NN','XX');
		$str = '';
    	$s1   = '';
    	foreach ($arr as $item) {
    		$check = '';
    		if ($item == $wuser->status) {
    			$check = 'checked';
    		}
    		$str = $str.PHP_EOL.$s1.'<input type="radio" name="stts[]" value="'.$item.'" '.$check.'>'.tb_word('status-'.$item);
    		$s1  = '<br>';
    	}
		echo $div_row  . $div_col1 .' </div>';
		echo $div_col2 . $str . '</div></div>';		
	}

?>
<input type="submit" class="submit" name="btnUpdate" value="Save">
<input type="submit" class="submit" name="btnCancel" value="Cancel">
</form>
