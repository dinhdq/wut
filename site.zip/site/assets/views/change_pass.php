<script>
	function scrwidth() {
		var dv = document.getElementById("login");
		var sd = window.screen.width;
		var w = "100%";
		
		if (sd > 800) {
			w = "800px";
		}
		dv.style.width = w;
	}
</script>
<div id="login">

<?php
	
	$maker = new html_maker();     
    $tbl   = new my_table('login');
    $tbl->get_configs();

    $tbl->set_caption(tb_title($title));
        
    $tbl->header_off();
    
    $tbl->remove_columns();
    $tbl->add_column($tbl->col_by_data('label|Label|30%|left|alt'));
    $tbl->add_column($tbl->col_by_data('data|Data|70%|left'));

    echo PHP_EOL.'<form action="'.tb_uri('change_pass').'" method="post">';
    echo PHP_EOL.'<input type="hidden" name="uid"   value="'.$user->user_id.'">';
    echo PHP_EOL.'<input type="hidden" name="uname" value="'.$user->user_name.'">';
    echo PHP_EOL.'<input type="hidden" name="token" value="'.$token.'">';
    
    $tbl->add_header();

	$s1 = $maker->submit_string(array('name'=>'btnChange', 'type'=>'submit','class'=>'submit', 'value'=>'Change'));
	$s1 = $s1.$maker->submit_string(array('name'=>'btnCancel', 'type'=>'submit','class'=>'submit', 'value'=>'Cancel'));

    $tbl->add_row(array(tb_word('old-password').':', $maker->input_field('old_pass',    NULL, array('type'=>'password'))), 'td');
    $tbl->add_row(array(tb_word('new-password').':', $maker->input_field('new_pass',    NULL, array('type'=>'password'))), 'td');
    $tbl->add_row(array(tb_word('re-type').':',      $maker->input_field('retype_pass', NULL, array('type'=>'password'))), 'td');

	if ($err1 != NULL) {
	    $tbl->add_row(array(tb_word('error').':', tb_msg('common', $err1)), 'td');		
	}

    $tbl->add_end();
		
    
	if ($err2 != NULL) {
	    echo '<br><pre class="bg-warning">'.tb_print_text('change_password', 1).'</pre>';
	}
	echo '<p style="text-align: center; line-height: 64px">'.$s1.'</p>';

    echo PHP_EOL.'</form>';
?>
</div>
<script>
	scrwidth();
</script>