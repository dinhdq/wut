<?php
class Home extends CI_Controller {  
    public function __construct() {
        parent::__construct();
		    $this->load->helper('url');
    }

    function index(){
        $curl = curl_init();
        $keyword = '';
        $sort = 'id';
        if (empty($_POST)){
          curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/get_all_contacts',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_HTTPHEADER => array(
              'Client-Id: 123456',
              'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
              'Content-Type: application/json'
            ),
          ));
          
          $response = curl_exec($curl);
          curl_close($curl);
        }
        else{
          $keyword = sanitize($this->input->post('keyword'));
          $sort = sanitize($this->input->post('sort'));
          curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/search_contact',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{
              "keyword": "'. $keyword .'",
              "sort": "' . $sort . '"
          
          }',
            CURLOPT_HTTPHEADER => array(
              'Client-Id: 123456',
              'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
              'Content-Type: application/json'
            ),
          ));
          
          $response = curl_exec($curl);
          
          curl_close($curl);
                    
        }

        $response = json_decode($response, true);
        $data = array();
        $data['sort'] = $sort;
        $data['keyword'] = $keyword;
        $data['contacts'] = $response['contacts'];
        
        
        $this->load->view('header');
        $this->load->view('contacts', $data);

    }

    function add_contact(){
      //$this->output->enable_profiler(TRUE);      
      $this->load->view('header');
      $data = array();
      $data['message'] = '';
      if (!empty($_POST)){
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $image_url = '';

        $config['upload_path']          = '/tmp/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 30000;
        $config['max_height']           = 30000;
        $this->load->library('upload', $config);
        if ($this->upload->do_upload('image')){
            $path = $this->upload->data()['full_path'];
            $file_name = uniqid();
            $new_path = FCPATH . 'files/' . $file_name;
    
            copy($path, $new_path);

            $image_url = 'https://weusthem.sacalabob.com/site/files/' . $file_name;
        }


        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/post_new_contact',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "first_name": "'. $first_name .'",
            "last_name": "'. $last_name .'",
            "email": "'. $email .'",
            "phone" : "'. $phone .'",
            "image_url" : "'. $image_url .'"
        
        }',
          CURLOPT_HTTPHEADER => array(
            'Client-Id: 123456',
            'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
            'Content-Type: application/json'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        $response = json_decode($response, true);
        $data['message'] = $response['message'];

      }
      $this->load->view('add_contact', $data);
      
    }

    

    function edit_contact(){
      //$this->output->enable_profiler(TRUE);      
      $this->load->view('header');
      $data = array();
      $data['message'] = '';
      if (!empty($_POST)){
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $phone = $this->input->post('phone');
        $image_url = '';

        $config['upload_path']          = '/tmp/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10000;
        $config['max_width']            = 30000;
        $config['max_height']           = 30000;

        $this->load->library('upload', $config);
        if ($this->upload->do_upload('image')){
            $path = $this->upload->data()['full_path'];
            $file_name = uniqid();
            $new_path = FCPATH . 'files/' . $file_name;
    
            copy($path, $new_path);

            $image_url = 'https://weusthem.sacalabob.com/site/files/' . $file_name;
        }


        $curl = curl_init();
        
        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/update_contact',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "first_name": "'. $first_name .'",
            "last_name": "'. $last_name .'",
            "email": "'. $email .'",
            "phone" : "'. $phone .'",
            "image_url" : "'. $image_url .'"
        
        }',
          CURLOPT_HTTPHEADER => array(
            'Client-Id: 123456',
            'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
            'Content-Type: application/json'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        $response = json_decode($response, true);
        $data['message'] = $response['message'];

      }

      $id = intval($this->input->get('id'));
      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/get_contact',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{
          "id": '. $id .'
      
      }',
        CURLOPT_HTTPHEADER => array(
          'Client-Id: 123456',
          'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
          'Content-Type: application/json'
        ),
      ));
      
      $response = curl_exec($curl);
      
      curl_close($curl);
      $response = json_decode($response, true);
      if ($response['success'] == 1){
        $data['contact'] = $response['contact'];
        $this->load->view('edit_contact', $data);
      }
      
    }

    function delete_contact(){
      if (!empty($_GET)){
        $email = sanitize($this->input->get('email'));
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/delete_contact',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS =>'{
            "email": "3"
        
        }',
          CURLOPT_HTTPHEADER => array(
            'Client-Id: 123456',
            'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
            'Content-Type: application/json'
          ),
        ));
        
        $response = curl_exec($curl);
        curl_close($curl);
        redirect('/');
                
      }
    }

}
?>
