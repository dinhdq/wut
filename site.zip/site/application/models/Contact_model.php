<?php
class contact_model extends CI_Model
{
    function __construct()
    {
    	$this->load->database();
        parent::__construct();
    }
    
    /*
     * Get shop by id
     */
    function get_contact($id)
    {
        return $this->db->get_where('contact',array('id'=>$id))->row_array();
    }

    function get_all_contacts()
    {
        return $this->db->get('contact')->result_array();
    }

    function get_all_contacts2($sort_by)
    {
        $this->db->order_by($sort_by);
        return $this->db->get('contact')->result_array();
    }


    function add_contact($params)
    {
        $email = $params['email'];
        if ($this->check_email_exist($email)){
            return 0;
        }
        $this->db->insert('contact',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update contact
     */
    function update_contact($email, $params)
    {
        $this->db->where(array('email'=>$email));
        $this->db->update('contact',$params);
    }
    
    /*
     * function to delete contact
     */
    function delete_contact($emaii)
    {
        $this->db->delete('contact',array('email'=>$emaii));
    }

    function check_email_exist($email){
        $row = $this->db->get_where('contact',array('email'=>$email))->row_array();
        if ($row){
            return true;
        }
        return false;
    }

    function search_contacts($keyword, $sort){
        $this->db->select('*');
        $this->db->from('contact');
        if ($keyword != ''){
            $this->db->like('first_name', $keyword, 'both');
            $this->db->or_like('last_name', $keyword, 'both');
            $this->db->or_like('email', $keyword, 'both');
            $this->db->or_like('phone', $keyword, 'both');
        }
        if ($sort !=''){
            $this->db->order_by($sort);
        }
        return $this->db->get()->result_array();
    }


}
?>