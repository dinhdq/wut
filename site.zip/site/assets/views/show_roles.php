
<?php 
	
	if (ktk_check_token($token) != 0) {
		return;
	}

    $tbl = new my_table('list');
    $tbl->get_configs();
    
    $class = 'admin';
	$wuser = new my_user();
	$data  = array();
	$data['token'] = $token;
	$data['id']    = $user_id;
	$data['name']  = $user_name;

	$roles = $cat->roles_data();
	
	$wuser->load_user($data);

    $tbl->set_caption(tb_word('user').': '.$wuser->user_name.' ('.$wuser->full_name.')');
	$tbl->set_config('width','100%', 'mydata');
	
    $tbl->header_on();
        
    $tbl->remove_columns();
    $tbl->add_column(NULL,'role|'.     tb_word('roles').     '|40%|left');
    $tbl->add_column(NULL,'function|'. tb_word('function').  '|40%|left');
    $tbl->add_column(NULL,'yes|'.      tb_word('yes').       '|20%|center');

    $tbl->add_header();

	$show = 0;

	if (is_array($roles)==true) {
		foreach ($roles as $key=>$value) {
		
			$s1 = ($show == 1) ? '[show]'.$key : '';
		
			$prefix  = substr($key,0,2);
			$k1 = $key;
			if ($prefix === '__') {
				$k1 = substr($key,2, strlen($key)-2);
			}
			$checked = ($wuser->role_check($key)) ? '[yes]' : '-';
			
			$a = array();
			$a[] = ($prefix==='__') ? tb_title($k1) : $s1;
			$a[] = ($prefix==='__') ? $s1 : tb_title($k1);			
			$a[] = $checked;
			
			if ($prefix==='__') {
				$tbl->add_row($a, 'odd');			
			} else {
				$tbl->add_row($a);
			}
		}
	}

   	$tbl->add_end();        
?>
<br>
<div align = "center">
	<form action="menu" method="post">
		<input type="submit" class="submit" name="btnBack" value="Back" align="center">
	</form>
</div>
<br>
