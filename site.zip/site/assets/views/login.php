<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
    if ($id <= 0) {
    	$name = '';
    }
    
	$maker = new html_maker();     
    $tbl   = new my_table('login');
    $tbl->get_configs();
?>

<script>
	function scrwidth() {
		var dv = document.getElementById("login");
		var sd = window.screen.width;
		var w = "100%";
		
		if (sd > 800) {
			w = "800px";
		}
		dv.style.width = w;
	}
</script>

<div id="login">
<?php

    $tbl->set_caption($title);
        
    $tbl->header_off();
    $tbl->set_table_width('100%');

    $tbl->remove_columns();
    $tbl->add_column($tbl->col_by_data('label|Label|34%|left|alt'));
    $tbl->add_column($tbl->col_by_data('data|Data|66%|left'));

    echo PHP_EOL.'<form action="'.tb_uri('signin').'" method="post">';

    $s1 = $maker->submit_string(array('name'=>'btnLogin', 'type'=>'submit','class'=>'submit', 'value'=>'Sign In'));

    $tbl->add_header();

    $tbl->add_row(array(tb_word('user-name').':', $maker->input_field('user_name',$name)), 'td');
    $tbl->add_row(array(tb_word('password').':',  $maker->input_field('user_pass', NULL, array('type'=>'password'))), 'td');
    
    if ($errs != NULL) {
    	$tbl->add_row(array('', tb_word('users.login','error')), 'td');
    }

    $tbl->add_end();
	//echo '<br>&nbsp;';
	echo '<p style="text-align: center; line-height: 64px">'.$s1.'</p>';
    echo '</form>';
?>
</div>
<script>
	scrwidth();
</script>