
<?php 
	$data = $cat->load_news(0,'system.list.home-page.admin');
	
?>

<div class="jumbotron text-center">
  <h1 type="home"><?php echo $data['title'] ?></h1>
  <p  type="title"><?php echo $data['notes'] ?></p> 
</div>

<div class="tb-update">
<?php
	$str_row = PHP_EOL.'<div class="row" type="home">';
	$str_col = PHP_EOL.'<div class="col-sm-4" type="td">';
	$div_end = PHP_EOL.'</div>';

	if (array_key_exists('news', $data) && is_array($data['news'])) {
		
		$i1 = 0;
		$count = count($data['news']);
		$i2 = 0;
		foreach ($data['news'] as $a) {
		
			echo ($i1==0) ? $str_row : '';
			echo $str_col;
	      	echo '<h3 type="home">' . $a['title'] . '</h3>';
			echo '<p  type="home">' . $a['notes'] . '</p>';
			echo $div_end;
			
			$i1++;
			$i2++;
			
			$i1 = ($i1>=3) ? 0 : $i1;
			
			echo ($i1==0 || $i2==$count) ? $div_end : '';
		
		}
	}		
?>
</div>

