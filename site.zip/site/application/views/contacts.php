<style>
.auto-style1 {
	border: 1px solid #000000;
}

</style>    
<?php
function get_select($a, $b){
    if ($a == $b){
        return "selected";
    }
    return '';
}
?>
<form method="post">
    <table>
        <tr>
            <td>Keyword</td>
            <td><input id="keyword" name="keyword" type="text" value="<?php echo($keyword)?>"></td>
        </tr>
        <tr>
            <td>Sort by</td>
            <td>
                <select name="sort">
                    <option value="id"></option>
                    <option value="first_name" <?php echo(get_select($sort, 'first_name'))?>>First Name</option>
                    <option value="last_name" <?php echo(get_select($sort, 'last_name'))?>>Last Name</option>
                    <option value="email" <?php echo(get_select($sort, 'email'))?>>Email</option>
                    <option value="phone" <?php echo(get_select($sort, 'phone'))?>>Phone</option>
                </select>
            </td>
        </tr>
    </table>   
    <input type="submit" value="Search">
</form>
<table cellpadding="5" cellspacing="0" class="auto-style1" style="width: 100%">
    <tr>
        <th class="auto-style1">
            First name
        </th>
        <th class="auto-style1">
            Last name
        </th class="auto-style1">
        <th class="auto-style1">
            Email
        </th class="auto-style1">
        <th class="auto-style1">
            Phone
        </th>
        <th class="auto-style1">
            Image URL
        </th>
        <th class="auto-style1">
            Edit
        </th>
        <th class="auto-style1">
            Delete
        </th>
    </tr>
    <?php
    foreach($contacts as $row){
    ?>
    <tr>
        <td class="auto-style1">
            <?php echo($row['first_name'])?>
        </td>
        <td class="auto-style1">
        <?php echo($row['last_name'])?>
        </td>
        <td class="auto-style1">
            <?php echo($row['email'])?>
        </td>
        <td class="auto-style1">
            <?php echo($row['phone'])?>
        </td>
        <td class="auto-style1">
            <?php echo($row['image_url'])?>
        </td>
        <td class="auto-style1">
            <a href="edit_contact?id=<?php echo($row['id'])?>">Edit contact</a>
        </td>
        <td class="auto-style1">
            <a href="#" onclick="delete_contact('<?php echo(urlencode($row['email']))?>')">Delete contact</a>
        </td>

    </tr>    
    <?php
    }
    ?>
</table>
<script>
    function delete_contact(email){
        if (!confirm('Are you sure you want to delete this contact?')){
            return;
        }
        location.href = "delete_contact?email="+email;
    }
</script>