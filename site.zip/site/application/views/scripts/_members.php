<?php

function msg_view_comments($mem, $box, $mid) {
	$blank = tb_uri('members/inbox/'.$box);
	$mem->load_message();
	$row = $mem->msg->_get($mid);
	
	if (is_array($row) == false) {
		return;
	}
	echo '<div id="msg-list">';
	show_single_message($mem, $row, $box);
	echo '</div>';	
}

function member_array() {
 	$a2   = array();
 	$a2[] = array('label'=>'member-name',  'field'   =>'member_name', 'class'=>'odd');
 	$a2[] = array('label'=>'full-name',    'field'   =>'full_name');
 	$a2[] = array('label'=>'email',        'field'   =>'email');
 	$a2[] = array('label'=>'phone',        'field'   =>'phone');
 	$a2[] = array('label'=>'max-shops',    'field'   =>'max_shops');
 	$a2[] = array('label'=>'package',      'field'   =>'package');
 	$a2[] = array('label'=>'status-text',  'field'   =>'status', 'class'=>'odd');
 	$a2[] = array('label'=>'create-date',  'field'   =>'signup_date');
 	$a2[] = array('label'=>'active-date',  'field'   =>'active_date');
 	$a2[] = array('label'=>'expire-date',  'field'   =>'expire_date');
 	$a2[] = array('label'=>'last-update',  'field'   =>'last_update');
 	$a2[] = array('label'=>'last-user',    'field'   =>'last_user');
 	$a2[] = array('label'=>'supporter',    'field'   =>'supporter');
 	$a2[] = array('label'=>'agent-name',   'field'   =>'agent_name', 'class'=>'odd');
	return $a2;
}

function member_msg_form($mem) {
    
    $styles = array('vertical-align'=>'center');
    
    echo PHP_EOL.'<form action="'.tb_uri('members/inbox').'" method="post">';
	echo PHP_EOL.'<input type="hidden" name="_member_id"   value="'.$mem->mydata['id'].'">';
	echo PHP_EOL.'<input type="hidden" name="_member_name" value="'.$mem->mydata['member_name'].'">';
	
	echo '<div type="message">';
	$a = array('support'=>'checked', 'public'=>'');
	echo '<table width = "100%" style="margin-bottom: 6px"><tr>';
	$str = '';
	foreach ($a as $key => $value) {
		$str = $str . '<td style="width: 5%; min-width: 36px; text-align: right">';
		$str = $str . '<input type="radio" class="radio" name="_list[]" value="'.$key.'" '.$value.'/></td>';
		$str = $str . '<td style="width: 45%; padding-left: 12px; vertical-align: center;">';
		$str = $str . '<label type="radio">'.tb_word($key).'</label></td>';
	}	
	echo $str;
	echo '</tr></table>';
	
	$str1 = tb_word('msg.subject');
	$str2 = '<input type="message" class="input" name="_subject" placeholder="'.$str1.'">';
	echo $str2;
	
	$str1 = tb_word('msg.content');
	$str2 = '<textarea type="message" name="_content" style="width: 100%" placeholder="'.$str1.'"></textarea>';	
	echo $str2;

	echo '<div style="width: 100%; text-align: right">';  	// 2
	echo '<input type="submit" class="post" name="btnPost"   value="Post">';
	echo '</div>';					// end of 2

	echo '</div>';					// end of 1
	echo '</form>';	
}

function member_show_messages($mem, $pno, $box = 'inbox', $sub='', $mid = 0) {
	$rows =	'msg.box-emptry.'.$box;
	if ($box != 'news') {
		$box  = 'inbox';
		$rows = $mem->inbox($pno);
	} else {
		$rows = $mem->news($pno);
	}
	
	echo '<div id="msg-list">';
	
	if (is_array($rows) == false) {
		member_msg_form($mem);
		echo '</div>';
		return;
	}
	
	member_msg_form($mem);

	foreach ($rows as $row) {
		show_single_message($mem, $row, $box);
	}
	echo '</div>';
}

function show_single_message($mem, $row, $box) {
	$s   = (string) $row['date'];
	if (strlen($s) > 5) {
		$s = substr($s, 5);
	}
	$id   = $row['id'];
	$name = $mem->property('member_name');
	$arr  = $mem->msg->get_likes($row, $name); 
		
	$content = '<i>'.$row['subject'].'</i><p>'.$row['content'];
	$line = post_bottom_line($id, $name, $arr);
		
	echo '<div type="message">';
	echo '<sender>{'.$row['sender'].'}</sender><br>';
	echo '<sub>'.$s.'</sub>';
	echo '<pre type="content">'.$content.'</pre>';
	echo $line;
	echo '<p id="comm_show_'.$id.'"></p>';
	echo '</div>';		
}

function post_bottom_line($id, $name, $likes) {

	$slike  = ' ('.$likes['likes'].')';
	$scom   = ' ('.$likes['comments'].')';
	$scolor = ($likes['liked'] == true) ? 'color: darkcyan;' : 'color: #808080;';
	$scolor = $scolor . ' font-size: 120%';

	$a = array();
	$a['like']    = array('<i class="fa fa-thumbs-up" aria-hidden="true" style="'.$scolor.'"></i>', tb_word('like').$slike,   $scolor);
	$a['comment'] = array('<span class="glyphicon glyphicon-comment" style="color:peru"></span>',   tb_word('comment').$scom, 'color: peru;');
	$a['delete']  = array('<span class="glyphicon glyphicon-trash" style="color:peru"></span>',     tb_word('delete'),        'color: peru;');

	$line = '';
	$tm   = 300;	
	$tk   = ktk_get_token($tm);
	$url  = tb_uri('api');
	
	foreach ($a as $key=>$b) {
		
		$s4 = 'id="' . $key . '_' . $id . '" ';
	
		$s3 = '</span>';
		$line = $line . '<span id ="comm_'.$key.'_'.$id.'">';
		$line = $line . '<span onclick="'.$key.'Clicked(' . $id . ','. "'" . $tk . "','" . $url . "'" ;
		$line = $line . ",'" . $name . "'";
		$line = $line . ')">';
		$line = $line . $b[0];
		$line = $line . '<span type="links">'. $b[1] . '</span></span>';	
		$line = $line . '</span>';
	}
	return $line;
}

function show_profile($mem, $cat) {

	$tbl = new my_table('member');
	$tbl->set_caption($cat->row['title']);
	
	$tbl->remove_columns();
	$tbl->set_defaults();
	$tbl->_caption('left');
	
	$tbl->add_column($tbl->col_by_data('label|Label|25%|left|alt'));
	$tbl->add_column($tbl->col_by_data('data|Input|75%|left'));
		
	$tbl->header_off();
	$tbl->add_header();

	$arr = member_array();	
	foreach ($arr as $a1) {
		$label = $a1['label'];
		$field = $a1['field'];
		$field = str_replace('((ST))', $mem->mydata['status'], $field);
		$text  = $field;
		if (array_key_exists($field, $mem->mydata)) {
			$text = ($field == 'status') ? tb_word('status-'.$mem->mydata[$field]) : $mem->mydata[$field];
		}
		$class = (array_key_exists('class', $a1)) ? $a1['class'] : 'td';
		$tbl->add_row(array(tb_word($label), $text), $class);	
	}
	$tbl->add_end();
	return;
}

?>
