<form method="post" onsubmit="return check()" enctype="multipart/form-data">
    <input id="id" name="id" value="<?php echo($contact['id'])?>" type="hidden">
    <?php
    echo($message);
    ?>
    <table>
        <tr>
            <td>
                First name
            </td>
            <td>
                <input id="first_name" name="first_name" type="text" value="<?php echo($contact['first_name'])?>">
            </td>
        </tr>
        <tr>
            <td>
                First name
            </td>
            <td>
                <input id="last_name" name="last_name" type="text" value="<?php echo($contact['last_name'])?>">
            </td>
        </tr>
        <tr>
            <td>
                Email
            </td>
            <td>
                <input id="email" name="email" type="text" value="<?php echo($contact['email'])?>">
            </td>
        </tr>
        <tr>
            <td>
                Phone
            </td>
            <td>
                <input id="phone" name="phone" type="text" value="<?php echo($contact['phone'])?>">
            </td>
        </tr>
        <tr>
            <td>
                Image file
            </td>
            <td>
                <img src="<?php echo($contact['image_url'])?>" height="300">
            </td>
        </tr>

        <tr>
            <td>
                Image file upload
            </td>
            <td>
                <input id="image" name="image" type="file">
            </td>
        </tr>
    </table>    
    <input type="submit" value="Update contact">
</form>
<script>
    function check(){
        var first_name = document.forms[0].first_name.value;
        if (first_name == ''){
            document.forms[0].first_name.focus();
            alert('Please input first name');
            return false;
        }
        var last_name = document.forms[0].last_name.value;
        if (last_name == ''){
            document.forms[0].last_name.focus();
            alert('Please input last name');
            return false;
        }

        var email = document.forms[0].email.value;
        if (email == ''){
            document.forms[0].email.focus();
            alert('Please input email');
            return false;
        }

        var phone = document.forms[0].phone.value;
        if (phone == ''){
            document.forms[0].phone.focus();
            alert('Please input phone');
            return false;
        }

        var image_url = document.forms[0].image_url.value;
        if (image_url == ''){
            document.forms[0].image_url.focus();
            alert('Please input image_url');
            return false;
        }

    }
</script>