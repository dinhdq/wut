<?php
	function sanitize($text){
		return $text;
	}
?>