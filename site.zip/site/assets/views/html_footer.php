                </td>
            </tr>
        </table>
        </td>
    </tr>
    <tr><td>
            <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>
        </td>
    </tr>
</table>    
    

</body>
</html>