<?php
class My_message {
	public  $model;
	private $limit;
	public  $mydata;
	
	public function __construct($id = 0)
	{
	    $CI =& get_instance();
	    $CI->load->model('message_model');
	    $this->model = new message_model();
	    $this->lines = 15;    
	}

	public function _get($id) {
		$row = $this->model->_get($id);
		return $row;
	}

	public function _send($token, $sender, $data) {
		$errs = array();
		if (ktk_check_token($token) != 0) {
			$errs[] = 'token';
		}
		
		$sender = trim($sender);
		if (strlen($sender) < 4) {
			$errs[] = 'msg.no-or-wrong-sender';
		}
		
		$subject = array_value_by_key('subject', $data); 

		$receivers = array_value_by_key('receivers', $data);
		if (strlen($receivers)==0) {
			$errs[] = 'msg.no-receivers';			
		}
		
		$content = array_value_by_key('content', $data);
		if (strlen($content)==0) {
			$errs[] = 'msg.no-content';			
		}
		//echo 'go 1  -> ';
		if (count($errs) > 0) {
			foreach ($errs as $err) {
				echo '<br>'.$err;
			}
			return $errs;
		}
		//echo 'go 2  -> ';
		$data['date']      = date('Y-m-d h:m:s');
		$id = $this->model->_add($data);
		
		if ($id == 0) {
			//echo 'go 3  -> ';
			return array('msg.send-failed');
		}
		//echo 'go 4  -> ';
		
		return $id;
	}

	public function inbox($name, $page=0) {
		$offset = $page * $this->limit;
		$rows   = $this->model->inbox($name, $offset, $this->limit);
		return $rows;
	} 

	public function news($name, $page=0) {
		$offset = $page * $this->limit;
		$rows   = $this->model->news($name, $offset, $this->limit);
		return $rows;		
	}

	public function get_likes($row, $name) {

		$arr = array();
    	$arr['likes']    = 0;
    	$arr['comments'] = 0; 
    	$arr['liked']    = false;
    	$arr['names']     = NULL; 
    	if (!is_array($row) || count($row) == 0) {
    		return $arr;
    	}

    	$arr['comments'] = $row['com_count']; 
    	
    	$name  = trim(strtolower($name));
    	$likes = $row['likes'];

		$a = json_decode($likes, true);
		
		if (is_array($a) == false || count($a) == 0) {
    		return $arr;			
		}
		if (in_array($name, $a)) {
			$arr['liked'] = true;
		} 

		$b = array();
		$count = 0;
		foreach ($a as $item) {
			$item = trim($item);
			if ($count < 10) {
				$b[] = $item;
			} else {
				break;
			}
			$count++;
		}
		
   		$arr['likes'] = count($a);
   		$arr['names'] = $b;
		return $arr; 
	}

	public function _like($id, $name) {
		$this->model->_like($id, $name);
	}

	public function msg_comments($id) {
		$rows = $this->model->post_comments($id);
		return $rows;
	}
	
	public function post_comments_text($id, $name = NULL) {
		$rows = $this->model->post_comments($id);
		if (is_array($rows) == false && count($rows) == 0 ) {
			return '';
		}
		
		$s1 = ''; 
		foreach ($rows as $row) {
			$s3 = (string) $row['date'];
            $s1 = $s1 . '<p type="comment">';
        	$s1 = $s1 . '<label type="comment-name">'  . $row['name']    . '</label>';  
            $s1 = $s1 . '<br>' . $row['content'];
            $s1 = $s1 . '<br><label type="comment-sub">' . $s3 . '</label></p>'; 
            $s1 = $s1 . PHP_EOL;
		}
		
		if ($name == NULL) {
			return $s1;
		}
		
		$tk    = ktk_get_token(300);
		$url   = tb_uri('api');
		$click = 'onclick="postTapped(' . $id .",'" . $tk . "','" . $url . "','" . $name ."'" .')" ';
		$s2 = '';
		//$s2 = '<form id="frmComments'.$id.'" ' . $click . 'method="post">';
        $s2 = $s2 . '<table width="100%"><tr>';
        $s2 = $s2 . '<td style="width:10%;text-align: center">';
        $s2 = $s2 . '<i class="fa fa-camera" aria-hidden="true" style="color: #808080; font-szie: 200%"></i></td>';        
        $s2 = $s2 . '<td style="width:80%;"><input id="_content_'.$id.'" type="message" class="input" name="comm_content_'.$id.'" placeholder="'.tb_word('comment-post').'" value=""/></td>';
        $s2 = $s2 . '<td style="width:10%; text-align: center"><input type="submit" '.$click.' class="comments" name="btnCom_'.$id.'" value="Post"/></td>';
        $s2 = $s2 . '</tr></table>';
        //$s2 = $s2 . '</form>';

		$text = $s1 . $s2;
		return $text;
	}
	
	
	
	public function msg_welcome() {
		$row = $this->model->system_message(0);
		return $row;
	}

	public function check_receiver($receiver, $row) {
		if (is_array($row) == false || count($row) == 0 || array_key_exists('receivers', $row)==false) {
			return false;
		}
		$receiver = trim(strtolower($receiver));
		$str = strtolower($row['receivers']);
		$s1  = '#' . $receiver . '#';
		$s2  = '|' . $receiver . '|';
		$s3  = '#all#';
		
		$res = strpos($str, $s1);
		if ($res !== false) {
			return true;
		}
		
		if (strpos($str, $s3) !== false) {
			if (strpos($str, $s2) !== false) {
				return false;
			} else {
				return true;
			}
		}
		
		return false;
	}

	public function empty_message() {
		$fields = $this->model->my_fields();
		$arr    = array();
		foreach ($arr as $key) {
			$value = '';
			if ($key == 'id') {
				$value = 0;
			} else if ($key == 'master_id') {
				$value = -1;
			} else if ($key == '') {
				$value = date('Y-m-d h:m:s');
			}
			$arr[$key] = $value;
		}
		return $arr;
	}	
}
?>