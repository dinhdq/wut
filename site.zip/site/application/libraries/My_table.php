<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class My_Table {
    
    // KTK: Version:      1.0
    //      Created by:   Khuc Trung Kien
    //      Created date: 25 Aug 2016
    //      Last Updated: 25 Aug 2016
    
    // These properties are fixed
    private $name;
    private $caption;
    private $columns;
    private $has_header;
    private $my_url;
    private $my_api_url;
    private $rows1;           // default configs
    private $rows2;           // table configs
    
    //KTK: these are for thiking ....
    private $css_file;
    private $data_file;
    private $translate;
    private $border_on;
    
    public function __construct($tblname = NULL) {
        
        if ($tblname == NULL) {
            $tblname = 'list';
        }

        if (is_string($tblname) == FALSE) {
            $tblname = 'list';
        }
        
        $CI =& get_instance();
        
        $this->name = trim(strtolower($tblname));
        $this->my_url = $CI->config->item('base_url');
        $this->my_api_url = 'http://localhost/myadmin/index.php/api/';

        //$CI->load->helper('');
        $this->border_on   = true;
        
        $this->load_default();
        //$this->get_configs();
    }
    
    public function load_default() {
        
        $this->caption     = 'This is table class';
        $this->has_header  = TRUE;
        $this->translate   = false;
        
    }

    public function set_configs($rows, $option = 0) {
        if (is_array($rows) == FALSE) {
            return;
        }
        if ($option == 1) {
            $this->rows1 = $rows;            
        } else {
            $this->rows2 = $rows;
        }
    }
    
    public function get_configs($class = NULL) {
        
        if ($class == NULL || is_string($class) == FALSE) {
        	$class = $this->name;
        }
        
        //
        // new: text file version
        //      
        $CI =& get_instance();
        if ($CI->config->item('mysite_is_admin')) {
            $this->rows1 = tb_table_rows();
            $this->rows2 = tb_table_rows($class);
        } else {
            $this->rows1 = $this->table_configs();
            $this->rows2 = $this->table_configs($class);            
        }
    }
    
    private function table_config($name = 'default') {
        $maker = new html_maker();
        
        $args = array();
        $args['token'] = ktk_get_token();
        $args['name']  = $name;
        
        $url = $maker->request_url_maker($this->my_api_url, 'table_configs', $args);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Set so curl_exec returns the result instead of outputting it.
        $response = curl_exec($ch);                      // Get the response and close the channel.
        curl_close($ch);
        
        $json = $response;
        $data = json_decode($json, TRUE);
        
        return $data;
        
    }
        
    private function api_get_items($class = NULL) {
        
        if ($class == NULL || is_string($class) == FALSE) {
        	$class = $this->name;
        }
        
        $maker = new html_maker();
        
        $args = array();
        $args['token'] = ktk_get_token();
        $args['group'] = 'table';
        $args['class'] = $class;
        
        $url = $maker->request_url_maker($this->my_api_url, 'get_config_items', $args);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Set so curl_exec returns the result instead of outputting it.
        $response = curl_exec($ch);                      // Get the response and close the channel.
        curl_close($ch);
        
        $json = $response;
        $data = json_decode($json, TRUE);
        
        return $data;
    }
    
    public function column_width($id, $width) {
        if (array_key_exists($id, $this->columns)) {
            $this->columns[$id]['width'] = $width;
        }
    }

    public function column_title($id, $title) {
        if (array_key_exists($id, $this->columns)) {
            $this->columns[$id]['title'] = $title;
        }
    }
    
    public function column_class($id, $class) {
        if (array_key_exists($id, $this->columns)) {
            $this->columns[$id]['class'] = $class;
        }
    }
    
    
    public function set_table_width($width) {
    	$this->set_config('width', $width);
    }  
    
    public function _caption($str = 'center', $data = NULL) {
    	
    	$str = trim(strtolower($str));
 		$s1 = '';   	
    	if ($str == 'center') {
    		$s1 = 'text-align:center; font-size:27px; background:#eeeeee; font-weight:bold; font-style:none';
    		$s1 = $s1 . '; padding-top: 18px; padding-bottom: 12px;';
    	} else if ($str == 'left') {
    		$s1 = 'text-align:left; font-size:21px; background:#fff; font-weight:normal; font-style:none';
    		$s1 = $s1 . '; padding-top: 12px; padding-bottom: 6px; color: #707070';    	
    	}
    	
    	$a1 = array();
    	$b = array_map('trim', explode(';', $s1));
    	foreach ($b as $s2) {
    		$c = array_map('trim', explode(':', $s2));
  			if (count($c) > 1) {  		
    			$a1[$c[0]] = $c[1];
    		}
    	}
    	
		$arr = array_map('trim', explode(';', $data));
		if (is_array($arr) && count($arr) > 0) {
			foreach ($arr as $s1) {
				$a2 = array_map('trim', explode(':', $s1));
				if (count($a2)> 1) {
					$a1[$a2[0]] = $a2[1];
				}
			}
		}

		foreach ($a1 as $key=>$value) {
			$this->set_config($key, $value, 'caption');
		}
				
    }
    
    public function set_defaults($data = NULL) {
    	$this->set_config('font-family', 'Times New Roman, Arial, Helvertica', 'alt');
    	$this->set_config('background-color', '#fafafa', 'th');
    	$this->set_config('font-weight', 'bold', 'th');
    	$this->set_config('color', '#505050', 'th');
    
    	$this->set_config('background-color', '#fafafa', 'alt');
    	$this->set_config('background-color', '#fafafa', 'odd');
    	$this->set_config('color', '#404040', 'cells');
    	$this->set_config('font-style', 'italic', 'alt');
    	$this->set_config('font-size', '115%', 'alt');
    	$this->set_config('vertical-align', 'top', 'alt');
    }
    
    public function set_config($key, $value, $item = NULL) {

        if ($this->rows2 == NULL) {
            $this->rows2 = array();
        } else if (is_array($this->rows2)==FALSE) {
            $this->rows2 = array();            
        } 
        
        if ($item == NULL) {
            $item = 'mydata';
        } else if (is_string($item) == FALSE) {
            $item = 'others';
        } else {
            $item = trim(strtolower($item));
            if (strlen($item) == 0) {
                $item = 'others';
            }
        }

        if (array_key_exists($item,$this->rows2)) {
            $this->rows2[$item][$key] = $value;
        } else {
            $this->rows2[$item] = array($key => $value);        
        }

    }
    
    public function set_translate($value = false) {
    	$this->translate = $value;
    }
	
    public function set_caption($str) {
        $this->caption = trim($str);
    }

    public function header_on() {
        $this->has_header = TRUE;
    }
    
    public function header_off() {
        $this->has_header = FALSE;
    }
    
    public function remove_columns() {
        $this->columns = array();
    }
    
    public function add_end() {
        echo PHP_EOL.'</table>';        
    }
    
    public function add_header() {
        
        $s1 = PHP_EOL.'  ';
        
        echo PHP_EOL;
        echo '<table';
        $styles = $this->style_data('table');
        $mydata = $this->style_data('mydata');
        while ($value = current($mydata)) {
            $key = key($mydata);
            if ($key == 'class') {
        		echo $this->style_inline($styles);
            } else {
                echo ' '.$key.' = "'.$value.'"';                    
            }
            next($mydata);
        }            
        echo '>';

        if ($this->caption != NULL) {
        	$a     = $this->style_data('caption');
        	$style = $this->style_inline($a);
        	 
            echo PHP_EOL.'<caption '.$style.'>';
            echo $this->caption.'</caption>';
        }

        // columns widths and text-aligns
        foreach ($this->columns as $col) {
            echo $s1.'<col width = "'.$col['width'].'"';
            echo ' align = "'.$col['align'].'">';
        }
        
        $style_th   = $this->style_inline($this->style_data('th'));
        $style_spec = $this->style_inline($this->style_data('spec'));
        
        if ($this->has_header) {
            echo PHP_EOL.'<tr>';
            
            
            foreach ($this->columns as $col) {
            
                $class = $style_th;
                $style = $col['class'];
                if ($style == 'spec') {
                    $class = $style_spec;;
                }
                echo $s1.'<td align = "'.$col['align'].'" '.$class.'>';
                $st = ($this->translate == true) ? tb_word($col['title'], 'common') : $col['title'];
                echo $st.'</td>';
            }
            echo PHP_EOL.'</tr>';
        }

    }

    public function add_row($data, $styles = NULL) {
        
        if (is_string($data)) {
            $data = explode('|', $data);
        }
        
        if (!is_array($data)) {
            $data = array();
        }
        
        $count = count($data); 
        $cols  = count($this->columns);
        
        for ($i = $count; $i < $cols; $i++) {
            $data[] = '-';
        }
        
        $type = 'td';
        if ($styles == NULL) {
            $type = 'td';
        } else if (is_array($styles)==false) {
        	$type = $styles;
        } 

        $style_td  = $this->style_inline($this->style_data('td'), $styles);
        $style_alt = $this->style_inline($this->style_data('alt'), $styles);

		$s2 = 'td';
        if ($type == 'th' || $type == 'spec') {
        	$s2 = 'th';
        	$style_td  = $this->style_inline($this->style_data('th'), $styles);
        	$style_alt = $this->style_inline($this->style_data('spec'), $styles);
        } else if ($type == 'odd') {
        	$style_td  = $this->style_inline($this->style_data('odd'), $styles);        
        } 

        $class = $this->name.'-'.$type;
        
        //echo 'class: '.$class;
        
        $type = trim($type);
        $type = strtolower($type);
        
        $s1 = PHP_EOL.'  ';
        
        echo PHP_EOL.'<tr>';

        $count = count($this->columns);

        $i = 0;
        foreach ($this->columns as $col) {
            $sclass = $style_td; 
            $style  = $col['class'];
            $style  = trim(strtolower($style));     
            if ($style != 'none') {
                $sclass = $style_alt;
            } 
            
            echo $s1.'<td align = "'.$col['align'].'" '.$sclass.'>';
            echo $data[$i];                
            echo '</td>';
            $i++;
        }
        
        echo PHP_EOL.'</tr>';
    }
    
    public function add_column($col = NULL, $text=NULL) {

        if ($col == NULL) {
            if ($text==NULL) {
                $index = count($this->columns);
                $col   = $this->col_default($index);
            } else {
                $col = $this->col_by_data($text);
            }
        }
        $id = $col['id'];
        $this->columns[$id] = $col;
    }
    
    public function col_by_data($data) {

        $col = $this->col_default();
        $col['title'] = '$data != string';
        
        if (!is_string($data)) {
            return $col;
        }

        $col['title'] = 'count < 4';

        $arr = explode('|', $data);
        if (count($arr) < 3) {
            return $col;
        }
        
        $i = 0;
        if (count($arr) > 3) {
          $i = 1;  
        } 
        
        $col['id']      = strtolower($arr[0]);
        $col['title']   = trim($arr[$i]);
        $col['width']   = trim($arr[$i+1]);
        $col['align']   = strtolower(trim($arr[$i+2]));
        $col['class']   = 'none';

        if (count($arr) > 4) {
            $col['class'] = trim(strtolower($arr[4]));
        }
        
        return $col;
    }
    
    public function col_default($index = NULL) {
        
        if ($index == NULL) {
            $index = count($this->columns);
        } 
        
        $id      = $index;
        $title   = $index;
        
        if (is_numeric($index)) {
            $id      = 'col'.$index;
            $title   = 'C'.$index; 
        }
        
        $id = strtolower($id);
        
        $col = array();
        $col['id']      = $id;
        $col['title']   = $title;
        $col['width']   = '100%';
        $col['align']   = 'left';
        $col['class']   = 'none';
        
        return $col;
    }
    
    
    public function output_styles($output = NULL) {
        // This is table '.$this->name.' styles
        // ====================================
        echo PHP_EOL;
        $this->echo_style('table');
        $this->echo_style('caption');
        $this->echo_style('th');
        $this->echo_style('spec', 'th');
        $this->echo_style('td');
        $this->echo_style('odd','td');
        $this->echo_style('alt','td');
        
    }
    
    public function echo_style($class, $type = NULL) {

        if ($type == NULL) {
            $type = '';
        }
        $type = trim($type);
        $type = strtolower($type);

        if (strlen($type) == 0) {
            $type = $class;
        }

        $s1 = '    ';
        $s2 = PHP_EOL.$s1.$s1;
        $s1 = PHP_EOL.$s1;
        
        $class = trim($class);
        $class = strtolower($class);
        
        $class_name = $type.'.'.$this->name.'-'.$class;

        echo PHP_EOL;
        echo $s1.$class_name.' {';
        
        $data = $this->style_data($class);
        
        while ($value = current($data)) {
            $key = key($data);
            echo $s2.$key.': '.$value.';';
            next($data);
        }
        
        echo $s1.'}';
    }

	public function border_off($on = false) {
		$this->border_on = $on;
	}
    
	public function style_inline($data = NULL, $styles = NULL) {
        if ($data == NULL || is_array($data)==FALSE) {
            return '';
        }

		if (!$this->border_on) {
			$data['border'] = '0px';
		}

        if ($styles != NULL && is_array($styles)==true) {
        	foreach ($styles as $key=>$value) {
        		$data[$key] = $value;
        	}
        }
            
        $vstr = ' style = "';
        $s1   = '';
        
        foreach ($data as $key=>$value) {
        	$vstr = $vstr.$s1.$key.': '.$value;
        	$s1 = '; ';
        }
        
        $vstr = $vstr.'"';
        return $vstr;
    }
    
    public function style_data($class) {
        
        $dat1   = array();
        $sclass = 'others';
        
        if (in_array($class, array('table','mydata', 'caption')) == TRUE) {
            $sclass = $class;
            $dat1   = $this->data_default($class);
            
        } else if (in_array($class, array('th','tr','td','spec','alt','odd')) == TRUE) {
            $sclass = 'cells';
            $dat1   = $this->data_default($sclass);
        } else {
            $dat1 = $this->data_default();
        }
        
        //
        //KTK: configs are default for all tables              --> $dat1
        //     default for all classes of types for this table --> $dat2
        //     configs for special class of this table         --> $dat3

        $dat2  = array();    
        $dat3  = array();
        
        if ($this->rows1 != NULL) {
            if (array_key_exists($sclass, $this->rows1)) {
                $a = $this->rows1[$sclass];
                foreach ($a as $key => $value) {
                    $dat1[$key] = $value;
                }
            }
        }
        
        if ($this->rows2 != NULL) {
            if (array_key_exists($sclass, $this->rows2)) {
                $dat2 = $this->rows2[$sclass];
            }
            if (array_key_exists($class, $this->rows2)) {
                $dat3 = $this->rows2[$class];
            }
            
        }
        
        foreach ($dat3 as $key => $value) {
            $dat2[$key] = $value;             
        }
        
        foreach ($dat2 as $key => $value) {
            $dat1[$key] = $value;             
        }
        
        if (!$this->border_on) {
        	$dat1['border'] = '0px';
        }
        return $dat1;
    }
    
    public function data_default($class = 'text') {
        $data = array();
        
        if ($class == 'mydata') {    
            $data['width']       = '100%';
            $data['align']       = 'center';
            $data['cellspacing'] = '0px';
            $data['empty-cells'] = 'show';
            $data['class']       = 'table';
	        if (!$this->border_on) {
    	    	$data['border'] = '0px';
        	}
            return $data;
        }
        
        if ($class == 'table') {
            $data['background-color'] = 'transparent';
            $data['border-collapse']  = 'collapse';
            $data['border']           = '1px solid #cccccc';
            $data['cellpadding']      = '0px';
            $data['cellspacing']      = '0px';
            $data['font-style']       = 'normal';
            $data['font-weight']      = 'normal';
            
	        if (!$this->border_on) {
    	    	$data['border'] = '0px';
        	}
            return $data;
        }
        
        // 
        // KTK: default for text, body, caption,...
        //
        $data['background-color'] = 'transparent';
        $data['color']            = 'black';
        $data['font-family']      = 'Helvetica, Arial, sans-serif';
        $data['font-size']        = '15px';
        $data['font-weight']      = 'normal';
        $data['text-decoration']  = 'none';

        // KTK: Adding OR change for cells (tr, th, td, spec, odd, alt)
        if ($class == 'cells') {
            $data['border-collapse']  = 'collapse';
            $data['font-size']        = '13px';
            $data['border']           = '1px solid #e9e9e9';
            $data['padding']          = '6px 6px 6px 6px';
            $data['line-height']      = '23px';
        } else if ($class == 'caption') {
            $data['padding']          = '12px 6px 0px 6px'; 
            $data['font-family']      = 'Times New Roman, Arial, sans-serif';
            $data['font-style']       = 'italic';
            $data['font-weight']      = 'normal';
            $data['text-align']       = 'right';
        }

        if (!$this->border_on) {
        	$data['border'] = '0px';
        }
        return $data;
    }
    
    public function clear_styles($option = 1) {
        if ($option == 1) {
    	   $this->rows1 = NULL;            
        } else {
            $this->rows2 = NULL;            
        }
    }
    
    // GET & SET
    
    public function table_name() {
        return $this->name;
    }
    
    public function table_caption() {
        return $this->caption;
    }
    
    public function table_rows($class = NULL) {
        if ($class == NULL || $class == $this->name) {
            return $this->rows2;            
        } 
        return $this->rows1;
    }
}