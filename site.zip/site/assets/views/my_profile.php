
<?php 

	if (ktk_check_token($token) != 0) {
		return;
	}

	$data  = array();
	$data['token'] = $token;
	$data['id']    = $user->user_id;
	$data['name']  = $user->user_name;
	
	if ($option != 0) {
		$data['id']    = $user_id;
		$data['name']  = $user_name;
	}
	
	$wuser = new my_user();
	$wuser->load_user($data);
	
?>

<!--
<table id="tbl" class="tb-update" align="center">
<tr><td class="td-update">
	<div class="title" type="title-center"><?php echo tb_word('User').': ['.$wuser->full_name.']'; ?></div>
</td></tr>
-->

<div class="table" type="update">

<?php 
	//$row_start = PHP_EOL.'<tr><td class="td-update">';	
	//$row_end   = PHP_EOL.'</td></tr>';
	$row_start = PHP_EOL.'<div class="row" type="update">';	
	$row_end   = PHP_EOL.'</div>';

    $data = $wuser->mydata();
    
    foreach ($data as $key => $value) {
    	echo $row_start;
    	
    	$s1 = 'alt';
    	$s2 = ($key == 'user-name' || $key == 'user-status') ? 'odd' : 'td';
    	
    	echo '<div class="col-sm-3" type="'.$s1.'">'.tb_word($key).':'.'</div>';
    	
    	$string = ($key == 'notes') ? '<pre>'.$value.'</pre>' : $value;
    	echo '<div class="col-sm-9" type="'.$s2.'">'.$string.'</div>';
    	
    	echo $row_end;
	}    
    echo $row_start;
    echo '<div class="col-sm-3" type="alt">'.tb_word('user-rights').':'.'</div>';
    echo '<div class="col-sm-9" type="td"><pre type="higher">'.$wuser->myroles('num').'</pre></div>';
    echo $row_end;

	if ($option == 1) {
		//echo '<tr><td>';
		
		echo '<form action="menu" method="post">';
		echo '<input type="submit" class="submit" name="btnBack" value="Back" align="center">';
		echo '</form>';
		//echo '</td></tr>';
    }
?>
</div>