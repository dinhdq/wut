<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
?>

<script>
	function scrwidth() {
		var sd = window.screen.width;
		var w = "100%";
		if (sd > 800) {
			w = "800px";
		}
		var dv = document.getElementById("login");
		dv.style.width = w;
	}
</script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>e-shop: access denied</title>
	<!-- this is boostrap -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php 
		include tb_css_file('eshop');
	?>    
</head>
<body>
<div id="login">
	<?php
    	echo '<h3 class="title">'.tb_word('access-denied','error').' - '.tb_word('access-'.$error,'error').'</h3>';
		echo '<pre style="font-size: 15px">'.tb_print_text('access_denied', 1).'</pre>';
   		echo '<a class="a1" href="'.tb_uri('signin').'">['.tb_msg('common','page.signin').']</a>';
	?>
    <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>'.CI_VERSION.'</strong>' : '' ?></p>
</div>
<script>
	scrwidth();
</script>
</body>
</html>
