<?php 

//
// KTK: Shows system messages with $code
//      data from "categories" database table
//      item from "system.list.help-text.*
//
function _ktk_system_message($name, $show_title = false) {
	$msg = new my_message();
	$row = $msg->msg_welcome();

	if ($msg->check_receiver($name, $row)==false) {
		return;
	}
	
	$tbl = new my_table();
	$tbl = new my_table('member');
	$tbl->set_caption($row['subject']);
	
	$tbl->remove_columns();
	$tbl->set_defaults();
	$tbl->_caption('left');
	
	$tbl->add_column($tbl->col_by_data('msg|Content|100%|left'));
		
	$tbl->header_off();
	$tbl->add_header();
	
	$content = $row['content'];
	$content = '<pre class="message">'. $content . '</pre>';
	$tbl->add_row(array($content));	
	
	$tbl->add_end();
	
	/*	
	echo '<div>';
	if ($show_title) {
		echo '<div><h4 type="message">' . $row['subject']. '</h4></div>';
	}
	$content = $row['content'];
	$days = 30;
	echo '<pre class="message">'. $content . '</pre>';
	echo '</div>';
	*/
	
	return; 
}

// 
// KTK: Show system errors messages
//      $errors is an array of errors code(s)
//      text to show from <language>/common.lines
//      lines started with "error.'
//
function _ktk_system_errs($errors) {
	if ($errors == NULL || is_array($errors) == true) {
		return;
	}
	
	echo '<div class="row" type="update">';
	echo '<div class="col-sm-3" type="err">'.tb_word('error').'</div>';
	echo '<div class="col-sm-9" type="err">';
	$s1 = '. ';
	foreach ($errors as $err) {
		echo $s1 . tb_word($err, 'error');
		$s1 = '<br>. ';
	}
	echo '</div>';
	echo '</div>';
}
	
?>

