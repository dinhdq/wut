<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
	$maker  = new html_maker();     
    $tbl    = new my_table('user');
    $title  = tb_title($title);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>e-shops: <?php echo $title ?></title>
	<!-- this is boostrap -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php 
		//echo '	<link rel="stylesheet" href="'.tb_css_file('eshop').'">';
		include tb_css_file('eshop');
	?>	        
</head>

<script>
	function scrwidth() {
		var dline = document.getElementById("divLeft");
		var dmenu = document.getElementById("divRight");
		
		var dv = document.getElementById("container");
		var sd = window.screen.width;
		var w = "100%";
		if (sd > 1000) {
			w = "1000px";
		} else {
			dline.setAttribute("style", "text-align: center;");
			dmenu.setAttribute("style", "text-align: center;");
		}
		dv.style.width = w;
	}
</script>

<body">
<div id="container">
	<div id="head-line">
		<div class="row">
    		<div id="divLeft" class="col-sm-6" style="text-align: left">
      			<hline id="headLine"><?php echo $title; ?></hline>
    		</div>
    		<div id="divRight" class="col-sm-6" style="text-align: right">
				<hmenu id="homeMenu"><?php echo $user->home_menu(); ?></hmenu>
    		</div>
  		</div>
  	</div>
<?php
    if ($cat->show_menu==1) {
		echo '<div id="menu-line">';
        $action = $cat->row->action;
        $cid    = $cat->row->id;
        $cat->print_menu($user->user_role);
    	echo '</div>';    
    }
    echo PHP_EOL;
?>
<div class="main-body">
