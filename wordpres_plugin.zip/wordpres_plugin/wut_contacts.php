<style>
.auto-style1 {
	border: 1px solid #000000;
}

</style>    
<?php
function get_select($a, $b){
    if ($a == $b){
        return "selected";
    }
    return '';
}
$keyword = safe_post('keyword');
$sort = safe_post('sort');

?>
<form method="post">
    <table>
        <tr>
            <td>Keyword</td>
            <td><input id="keyword" name="keyword" type="text" value="<?php echo($keyword)?>"></td>
        </tr>
        <tr>
            <td>Sort by</td>
            <td>
                <select name="sort">
                    <option value="id"></option>
                    <option value="first_name" <?php echo(get_select($sort, 'first_name'))?>>First Name</option>
                    <option value="last_name" <?php echo(get_select($sort, 'last_name'))?>>Last Name</option>
                    <option value="email" <?php echo(get_select($sort, 'email'))?>>Email</option>
                    <option value="phone" <?php echo(get_select($sort, 'phone'))?>>Phone</option>
                </select>
            </td>
        </tr>
    </table>   
    <input type="submit" value="Search">
</form>

<table cellpadding="5" cellspacing="0" class="auto-style1" style="width: 100%">
    <tr>
        <th class="auto-style1">
            First name
        </th>
        <th class="auto-style1">
            Last name
        </th class="auto-style1">
        <th class="auto-style1">
            Email
        </th class="auto-style1">
        <th class="auto-style1">
            Phone
        </th>
        <th class="auto-style1">
            Image URL
        </th>
    </tr>
    <?php
    $curl = curl_init();
    if (empty($_POST)){
        
        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/get_all_contacts',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => array(
            'Client-Id: 123456',
            'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
            'Content-Type: application/json'
        ),
        ));
        
        $response = curl_exec($curl);
        curl_close($curl);
        
    }
    else{
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://weusthem.sacalabob.com/site/api/search_contact',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{
              "keyword": "'. $keyword .'",
              "sort": "' . $sort . '"
          
          }',
            CURLOPT_HTTPHEADER => array(
              'Client-Id: 123456',
              'Client-Secret: PJLmALATicCqgO72FY7RvbH6obWUraa7',
              'Content-Type: application/json'
            ),
          ));
          
          $response = curl_exec($curl);
          
          curl_close($curl);
    }
    $response = json_decode($response, true);
    $contacts = $response['contacts'];

    foreach($contacts as $row){
    ?>
    <tr>
        <td class="auto-style1">
            <?php echo($row['first_name'])?>
        </td>
        <td class="auto-style1">
        <?php echo($row['last_name'])?>
        </td>
        <td class="auto-style1">
            <?php echo($row['email'])?>
        </td>
        <td class="auto-style1">
            <?php echo($row['phone'])?>
        </td>
        <td class="auto-style1">
            <?php echo($row['image_url'])?>
        </td>

    </tr>    
    <?php
    }
    ?>
</table>
