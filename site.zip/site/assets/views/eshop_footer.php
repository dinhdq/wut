
</div>
<p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds</p>    
</div>
<script>
	scrwidth();
</script>
</body>
</html>