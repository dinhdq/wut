
<?php 

	if (ktk_check_token($token) != 0) {
		return;
	}

	$maker = new html_maker(); 
    $tbl   = new my_table('list');
    $tbl->get_configs();
    
    $class = 'admin';

    $tbl->set_caption(tb_msg('admin', 'users.list'));
	$tbl->set_config('width','100%', 'mydata');
	
    $tbl->header_on();
        
    $tbl->remove_columns();
    $tbl->add_column(NULL,'no|'.     tb_msg('common','common.no').    '|5%|center');
    $tbl->add_column(NULL,'user|'.   tb_msg($class,'users.user').     '|10%|left|alt');
    $tbl->add_column(NULL,'type|'.   tb_msg($class,'users.type').     '|12%|left');
    $tbl->add_column(NULL,'name|'.   tb_msg($class,'users.name').     '|12%|left');
    $tbl->add_column(NULL,'status|'. tb_msg($class,'users.status').   '|10%|center|alt');
    $tbl->add_column(NULL,'links|'.  tb_msg($class,'users.updates').  '|46%|left');
    
    $tbl->add_header();

	$tk = session_get_value('_utk');

    $rows = $user->list_users();
    
    
    if (is_array($rows) == true) {
        $i  = 0;
        $sp = '&nbsp;&nbsp;';
        foreach ($rows as $row) {
            $i++;
            $a = array();
            $a[] = $i;
            $a[] = $row['user_name'];
            $a[] = tb_title($row['user_type']);
            $a[] = $row['full_name'];
            $a[] = tb_word('status-'.$row['status']);
            
            $uid   = $row['id'];
            
    		$args  = array('tk'=>$tk, 'id'=>$uid, 'name'=>$row['user_name']);

            $links = '';
            $links = $maker->add_totext($links, $user->link_inline('update_profile','admin.roles.users.update', true, $args),'[',']').$sp;
            $links = $maker->add_totext($links, $user->link_inline('psw_reset',  'admin.roles.users.reset-password', true, $args,'users.reset.password'),'[',']').$sp;
            $links = $maker->add_totext($links, $user->link_inline('user_roles', 'admin.roles.users.assign-roles', true, $args,'users.set.roles'),'[',']').$sp;
            $links = $maker->add_totext($links, $user->link_inline('show_user', 'admin.roles.users.show-user', true, $args),'[',']').$sp;
            $links = $maker->add_totext($links, $user->link_inline('user_remove','admin.roles.users.delete', true, $args),'[',']').$sp;
            
            $a[] = $links;
            $tbl->add_row($a);
        }    
    }
   	    
    //$tbl->add_row(array('Roles', $user->myroles()));
        
   	$tbl->add_end();        

?>
