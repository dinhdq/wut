<?php
function system_message($code) {
	if ($code == NULL) {
		return;
	}
	$c1 = new my_category();
	$c1->load_me(0, $code);
	if (!is_object($c1->row)) {
		return;
	}
	echo '<div>';
	//echo '<div><h3 type="red">' . $c1->row->title . '</h3></div>';
	$msg  = $c1->row->notes;
	$days = 30;
	$msg  = str_replace('((days))', (string) $days, $msg);
	echo '<pre class="message">'. $msg . '</pre>';
	echo '</div>';
	return; 
}

function show_profile($mem, $title) {
 	$a = array();
 
	$tbl = new my_table('member');
	$tbl->set_caption($title);
	$tbl->remove_columns();
	$tbl->set_config('width',   '100%');
	$tbl->add_column($tbl->col_by_data('label|Label|25%|left|alt'));
	$tbl->add_column($tbl->col_by_data('data|Input:75%|left'));
		
	$tbl->header_off();
	$tbl->add_header();
	$tbl->set_defaults();
	
	foreach ($mem->mydata as $key=>$value) {
		$tbl->add_row(array($key, $value));	
	}
	$tbl->add_end();
	return;
}

?>
