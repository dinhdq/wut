<?php
	require_once 'scripts/_system.php';
	require_once 'scripts/_members.php';
	
	if (ktk_check_token($token) !== 0) {
		return;
	} 
	
	$cat = new my_category();
	$cat->load_me(0, $code);

	$title = '['.strtoupper($mem->property('member_name')).']';	
	
?>
<div id="flex-box" class="flex-box">
<div type="left">
<?php 
	$sp   = '&nbsp;&nbsp;';
	$id   = $cat->search_id('members.menu.root');
	$rows = $cat->load_children($id);
	
	if (!is_array($rows)) {
		return;
	}
	echo '<ul class="nav navbar-nav">';
	foreach ($rows as $r1) {
		$action  = $r1['action'];
		$mtitle  = ($action == 'inbox') ? $mem->mydata['full_name'] : $r1['title'];
	
		$type  = ($r1['code'] === $code) ? ' type="active"' : '';
		$check = ($r1['code'] === $code) ? ' checked' : '';
		$sb1   = ($r1['code'] === $code) ? '<b>' : '';
		$sb2   = ($r1['code'] === $code) ? '</b>' : '';
		$icon  = '<span class="' . $r1['image'].'" style="color: teal;"></span>';
		echo '<li class="menu"'.$type.'><a href="'.tb_uri('members/'.$action).'">'.$icon.$sp.$mtitle . '</a></li>';
		if ($r1['code'] == $code && $r1['has_children'] == 1) {
			$a = json_decode($r1['notes'], true);
			foreach ($a as $key=>$value) {
				echo '<li class="menu" type="sub"><a href="'.tb_uri('members/'.$action.'/'.$key).'">'. $value . '</a></li>';			
			}
		} 
			
	}
	echo '</ul>';

?>	
</div>

<!--
	This is right area
-->

<div type="right">

<?php
	//echo $code;
	if ($mem->property('status') == '--') {
		_ktk_system_message('system.list.help-text.welcome');
	}

	$c1 = new my_category();
	$c1->load_me(0, $code);
	
	echo '<h3 type="title">'.$c1->row->title.'</h3>';
	
	if ($code == 'members.menu.root.profile') {
		show_profile($mem, $c1);
	}
	
?>
</div>
