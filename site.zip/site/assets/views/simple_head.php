<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
	$maker  = new html_maker();     
    $tbl    = new my_table('user');
    $title  = tb_title($title);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>e-shops: <?php echo $title ?></title>
	<!-- this is boostrap -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php 
		include tb_css_file('eshop');
	?>
</head>
<body>


