<?php
function _update_table($caption = '', $name = '') {

	$tbl = new my_table('member');
	$caption = $name . ' - ' . $caption;
	$tbl->set_caption($caption);
	
	$tbl->remove_columns();
	$tbl->set_config('width',   '100%');
	$tbl->add_column($tbl->col_by_data('label|Label|30%|left|alt'));
	$tbl->add_column($tbl->col_by_data('data|Input|70%|left'));
		
	$tbl->header_off();
	$tbl->set_defaults();

	return $tbl;
}

function _shop_formats() {

	$a2 = array();
 	$a2[] = array('label'=>'shop-name', 'type'=>'input',  'field' =>'name', 'class'=>'odd');
 	$a2[] = array('label'=>'address',   'type'=>'show',   'field' =>'', 'value'=>'');
 	$a2[] = array('label'=>'country',   'type'=>'input', 'field' =>'country');
 	$a2[] = array('label'=>'state',     'type'=>'input', 'field' =>'state');
 	$a2[] = array('label'=>'district',  'type'=>'input', 'field' =>'district');
 	$a2[] = array('label'=>'ward',      'type'=>'input', 'field' =>'ward');
 	$a2[] = array('label'=>'address',   'type'=>'input', 'field' =>'address');
 	$a2[] = array('label'=>'shop-type', 'type'=>'show',  'field' =>'domain', 'class'=>'odd');

	return $a2;
}

function _show_shop($data, $name = '') {
	$cat   = new my_category();
	$types = $cat->shop_types();
	
	$a2  = _shop_formats();

	$tbl = _update_table(tb_word('shop.information'));
	$tbl->set_caption($data['name']);
	$tbl->_caption('center');
	$tbl->set_config('text-align', 'left', 'caption');
	$tbl->set_config('font-size',  '21px', 'caption');
	$tbl->add_header();

	foreach ($a2 as $a1) {
		$label = $a1['label'];
		$field = $a1['field'];
		$class = (array_key_exists('class', $a1)) ? $a1['class'] : 'td';
		$value = '';
		if (array_key_exists('value', $a1)) {
			$value = $a1['value'];
		} else if (array_key_exists($field, $data)) {
			$value = $data[$field];
		}
		
		if ($field == 'word') {
			$value = tb_word($value);
		}
		
		if ($field == 'domain') {
			if (array_key_exists($value, $types)==false) {
				$value = 'system.list.shop-types.none';
			}
			$value = $types[$value]['title'];
		}
		
		$tbl->add_row(array(tb_word($label), $value), $class);
	}
	
	$tbl->add_end();
}

function _list_shops($rows, $id, $name = '') {

	$tbl = new my_table('member');
	$tbl->set_caption('');
	
	$tbl->remove_columns();
	$tbl->set_config('width',   '100%');
	
	$tbl->add_column($tbl->col_by_data('no|No|5%|center'));	
	$tbl->add_column($tbl->col_by_data('name|Name|25%|left'));
	$tbl->add_column($tbl->col_by_data('address|Address|70%|left'));
	$tbl->set_translate(true);	
	$tbl->header_on();
	$tbl->set_defaults();

	$tbl->add_header();
	
	$i = 0;
	foreach ($rows as $shop) {
		$i++;
		$cid = $shop['id'];
		$s1  = ($cid == $id) ? 'odd' : ''; 
		$s2  = ($cid == $id) ? '<span style="color: crimson;">>></span>&nbsp;&nbsp;' : '';
		$s3  = $shop['address'];
		$s3  = $s3 . (strlen($shop['ward']) > 0)     ? $s3 . ', ' . $shop['ward']     : ''; 	
		$s3  = $s3 . (strlen($shop['district']) > 0) ? $s3 . ', ' . $shop['district'] : '';
		$tbl->add_row(array($i, $s2. $shop['name'], $s2.$s3), $s1);
	}
	$tbl->add_end();
	
}

function _update_form($name = '', $data = NULL) {

	$cat   = new my_category();
	$types = $cat->shop_types();

	if (is_array($data)==false) {
		$data = array();
	}
	$a2 = _shop_formats();
	
	$tbl = _update_table(tb_word('shop.create'), $name);
	$tbl->add_header();

	$domain = 'system.list.shop-types.none';
	if (array_key_exists('domain', $data)) {
		$domain = $data['domain'];
	}
	
	foreach ($a2 as $a1) {
		$label = $a1['label'];
		$type  = $a1['type'];
		$field = $a1['field'];
		$class = (array_key_exists('class', $a1)) ? $a1['class'] : 'td';
		$value = '';
		if (array_key_exists('value', $a1)) {
			$value = $a1['value'];
		} else if (array_key_exists($field, $data)) {
			$value = $data[$field];
		}
		
		if ($field == '__word') {
			$value = tb_word($value);
		}
		
		$str1 = tb_word($a1['label']);
		$str2 = '';
		if ($type == 'input') {
			$str2 = $str2 . '<input type="input"';
			$str2 = $str2 . ' name="_' . $field   . '" ';
			$str2 = $str2 . ' value="' . $value . '">'; 
		} else if ($type == 'show') {
			if ($field == 'domain') {
				if (array_key_exists($value, $types)==false) {
					$value  = 'system.list.shop-types.none';
					$domain = $value;
				}
				$value = $types[$value]['title'];
			}
			$str2 = $str2 . $value;
		}
		$tbl->add_row(array($str1 , $str2), $class);
		
	}

	$tbl->add_end();

	$tbl->remove_columns();
	$tbl->set_config('width',   '100%');
	$tbl->set_config('border', '0px', 'cells');
	$tbl->set_config('text-align', 'left', 'caption');
	$tbl->set_config('color', 'crimson', 'caption');
	$tbl->set_config('font-size', '150%', 'caption');
	$tbl->set_caption(tb_word('select.shop.type'));
		
	$tbl->add_column($tbl->col_by_data('col1|Col1|8%|right'));	
	$tbl->add_column($tbl->col_by_data('col2|Col2|42%|left'));
	$tbl->add_column($tbl->col_by_data('col3|Col3|8%|right'));	
	$tbl->add_column($tbl->col_by_data('col4|Col4|42%|left'));

	$tbl->add_header();

	// show selection of shop-types
	$a   = array();	
	$col = 0;	
	foreach ($types as $key=>$row) {
		$check = ($domain == $key) ? ' checked' : '';
		$s1 = ($domain == $key) ? ' <b>' : '';
		$s2 = ($domain == $key) ? ' </b>' : '';
		$a[] = '<input type="radio" name="_types[]" value="'.$key.'"'.$check.'>';
		$a[] = $s1.$row['title'].$s2;
		$col++;
		if ($col>1) {
			$tbl->add_row($a);
			$col = 0;
			$a   = array();	
		}
	}
	
	if ($col == 1) {
		$a[] = '';
		$a[] = '';
		$tbl->add_row($a);
	}
	$tbl->add_end();
}

?>
