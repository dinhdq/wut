<?php
class Api extends CI_Controller {  
    public function __construct() {
        parent::__construct();
		$this->load->helper('url');
    }

    function authenticate($client_id, $client_secret){
        $this->load->model('client_model');
        $client = $this->client_model->get_client($client_id, $client_secret);
        if ($client){
            return true;
        }
        return false;
    }
    function get_all_contacts(){
        header('Content-type: application/json');
        $client_id = $_SERVER['HTTP_CLIENT_ID'];
        $client_secret = $_SERVER['HTTP_CLIENT_SECRET'];

        if (!$this->authenticate($client_id, $client_secret)){
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Authentication fail';
            echo(json_encode($result));
            return;
        }

        $this->load->model('contact_model');
        $contacts = $this->contact_model->get_all_contacts();
        $result = array();
        $result['success'] = 1;
        $result['message'] = 'Success';
        $result['contacts'] = $contacts;
        echo(json_encode($result));

    }

    function post_new_contact(){
        header('Content-type: application/json');
        $client_id = $_SERVER['HTTP_CLIENT_ID'];
        $client_secret = $_SERVER['HTTP_CLIENT_SECRET'];

        if (!$this->authenticate($client_id, $client_secret)){
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Authentication fail';
            echo(json_encode($result));
            return;
        }

        $data = file_get_contents("php://input");
        $data = json_decode($data, true);

        $params = array();
        $params['first_name'] = sanitize($data['first_name']);
        $params['last_name'] = sanitize($data['last_name']);
        $params['phone'] = sanitize($data['phone']);
        $params['email'] = sanitize($data['email']);
        $params['image_url'] = sanitize($data['image_url']);
        
        $this->load->model('contact_model');
        $contact_id = $this->contact_model->add_contact($params);
        if ($contact_id){
            $result = array();
            $result = array();
            $result['success'] = 1;
            $result['message'] = 'Success';
            echo(json_encode($result));
            return;
        }
        else{
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Post contact fail, email is existed';
            echo(json_encode($result));
        }
    }

    function update_contact(){
        header('Content-type: application/json');
        $client_id = $_SERVER['HTTP_CLIENT_ID'];
        $client_secret = $_SERVER['HTTP_CLIENT_SECRET'];

        if (!$this->authenticate($client_id, $client_secret)){
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Authentication fail';
            echo(json_encode($result));
            return;
        }

        $data = file_get_contents("php://input");
        $data = json_decode($data, true);
        $email = sanitize($data['email']);
        $this->load->model('contact_model');

        if (!$this->contact_model->check_email_exist($email)){
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Email not found';
            echo(json_encode($result));
            return;
        }

        $params = array();
        $params['first_name'] = sanitize($data['first_name']);
        $params['last_name'] = sanitize($data['last_name']);
        $params['phone'] = sanitize($data['phone']);
        $params['image_url'] = sanitize($data['image_url']);
        
        $this->contact_model->update_contact($email, $params);
        $result = array();
        $result['success'] = 1;
        $result['message'] = 'success';
        echo(json_encode($result));
    
    }

    function delete_contact(){
        header('Content-type: application/json');
        $client_id = $_SERVER['HTTP_CLIENT_ID'];
        $client_secret = $_SERVER['HTTP_CLIENT_SECRET'];

        if (!$this->authenticate($client_id, $client_secret)){
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Authentication fail';
            echo(json_encode($result));
            return;
        }

        $data = file_get_contents("php://input");
        $data = json_decode($data, true);
        $email = sanitize($data['email']);
        $this->load->model('contact_model');

        if (!$this->contact_model->check_email_exist($email)){
            $result = array();
            $result['success'] = 0;
            $result['message'] = 'Email not found';
            echo(json_encode($result));
            return;
        }
        $this->contact_model->delete_contact($email);
        $result = array();
        $result['success'] = 1;
        $result['message'] = 'success';
        echo(json_encode($result));


    }
}
?>
