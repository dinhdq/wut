<?php
    defined('BASEPATH') OR exit('No direct script access allowed');
	$maker  = new html_maker();     
    $tbl    = new my_table('user');
    $title  = tb_title($title);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>e-shops: <?php echo $title ?></title>
	<!-- this is boostrap -->
	<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php 
		include tb_css_file('eshop');
	?>	        
</head>
<body style="padding: 0; margin: 0px">

<table width="100%" cellspacing="0px" style="border: 0px; color: white; cellspacing: 0px; cellpadding: 0px 0px 0px 0px" align="center">
    <tr><td>
        <table width = "100%" style="background-color: darkcyan" cellspacing="0px" border="0px">
            <tr>
                <td style="padding: 6px 12px 6px 12px"><hline><?php echo $title; ?></hline></td>
                <td style="padding: 6px 12px 6px 12px; text-align: right"><hmenu><?php echo $user->home_menu(); ?></hmenu></td>
            </tr>
        </table>
        </td>
    </tr>
<?php
    if ($cat->show_menu==1) {
        echo PHP_EOL.'<tr><td>';
        echo '<table width = "100%" style="background-color: #dee2e3" cellspacing="0px" border="0px">';
        echo '<tr>';
        echo '<td style="padding: 6px 12px 6px 12px; color: #a3441c; font-size: 13px">';

        $action = $cat->row->action;
        $cid    = $cat->row->id;
        $cat->print_menu($user->user_role);
    
        echo PHP_EOL.'</td></tr></table></td></tr>';
    }    
?>
    
    <tr><td cellspacing="0px">
        <table width="100%" cellspacing="0px" cellpadding="0px" style="background-color: transparent" border="0px">
            <tr>
                <td width ="100%" style="color: darkred; font-style: italic; font-size: 17px">