<?php
class client_model extends CI_Model
{
    function __construct()
    {
    	$this->load->database();
        parent::__construct();
    }
    
    /*
     * Get shop by id
     */
    function get_client($client_id, $client_secret)
    {
        return $this->db->get_where('client',array('client_id'=>$client_id, 'client_secret'=>$client_secret))->row_array();
    }


    function add_client($params)
    {
        $this->db->insert('client',$params);
        return $this->db->insert_id();
    }
    
    /*
     * function to update client
     */
    function update_client($id,$params)
    {
        $this->db->where(array('id'=>$id));
        $this->db->update('client',$params);
    }
    
    /*
     * function to delete client
     */
    function delete_client($id)
    {
        $this->db->delete('client',array('id'=>$id));
    }


}
?>