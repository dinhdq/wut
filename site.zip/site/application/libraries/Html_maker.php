<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Html_maker {
    
    public function __construct() {
       
    }
        
    public function input_row($label, $name, $type = 'input', $data = NULL, $disable = '') {
        if ($data == NULL || is_array($data) == FALSE) {
            $data = array();
        }
     
     	$data['id']   = 'i'.$name;
        $data['name'] = $name;
     	$data['type'] = $type;
        
        $str = '<input';
        $s1  = ' ';
        $s2  = '"';
        
        foreach ($data as $key => $value) {
            $str = $str.$s1.$key.'='.$s2.$value.$s2;
            $s1  = '; ';
        }
        $str = $str.$disable.'/>';
        
        return array($label, $str);
    }
    
    public function input_field($name, $value, $data = NULL, $style = 'width: 100%') {
        if ($data == NULL || is_array($data) == FALSE) {
            $data = array();
        }
     
     	$data['id']    = 'i'.$name;
        $data['name']  = $name;
        $data['value'] = $value;
		
		if (array_key_exists('type', $data) == false) {
			$data['type'] = 'input';			
		}		

        $str = '<input';
        $s1  = ' ';
        $s2  = '"';
        
        foreach ($data as $key => $value) {
            $str = $str.$s1.$key.'='.$s2.$value.$s2;
        }
        $str = $str.' style="'.$style.'"/>';

		return $str;		    
    }
    
    public function submit_string($data = NULL) {
        
        if ($data == NULL || is_array($data) == FALSE) {
            return '';
        }
     	
        $str = ' <input';
        $s1  = ' ';
        $s2  = '"';
        
        foreach ($data as $key => $value) {
            $str = $str.$s1.$key.'='.$s2.$value.$s2;
            $s1  = '; ';
        }
        $str = $str.'/>';
        
        return $str;
    }
    
    public function head_tag($tag, $items = NULL, $styles = NULL) {
        $vstr = '<'.$tag;

        if ($items != NULL) {
            while ($value = current($items)) {
                $key  = key($items);
                $vstr = $vstr.' '.$key.' = "'.$value.'"'; 
                next($items);
            }
        }

        $vstr = $vstr.$this->style_inline($styles);
        
        $vstr = $vstr.'>';
            
        return $vstr;
    }
    
    public function insert_text($tag, $text, $class = NULL, $prefix = NULL) {
        if ($prefix != NULL) {
            echo $prefix;
        }
        echo '<'.$tag.'>';
        echo $text;
        echo '</'.$tag.'>';
    }
    
    public function adjust_text($text) {
        $text = $this->replace_code($text,'emphasised');
        $text = $this->replace_code($text,'p.emphasised');
        $text = $this->replace_code($text,'hline');
        $text = $this->replace_code($text,'hmenu');
        return $text;
    }
    
    public function replace_code($text, $code) {
        $text = str_replace('(('.$code.'))', '<'.$code.'>', $text);
        $text = str_replace('((/'.$code.'))', '</'.$code.'>', $text);
        return $text;        
    }
    
    public function view_styles() {

        // body
        $this->style_make('body');
        $this->style_make('a');
        $this->style_make('a:hover');
        $this->style_make('emphasised');

        // hline, hmenu, hlink
        $this->style_make('hline');
        $this->style_make('hmenu');
        $this->style_make('a.hlink');
        $this->style_make('a.hlink:hover');

        // p.footer; code; p.emphased
        
        $this->style_make('p.footer');
        $this->style_make('code');
        $this->style_make('p.emphasised');
        $this->style_make('input');
        $this->style_make('input.submit');
        //$this->style_make('input[type=submit]:disabled');
        $this->style_make('textarea');
        
    }
    

    // insert stylesheet style statement by elements array
    //      $name   : style's name
    //      $data   : array of elements
    public function style_make($name, $data = NULL, $stype = NULL) {
        $name = trim($name);
        if ($data == NULL) {
            $data = $this->style_data($name, $stype);
        }
        $s3 = '    ';
        $s2 = PHP_EOL.$s3.$s3;
        $s1 = PHP_EOL.$s3;
        
        echo PHP_EOL;
        echo $s1.$name.' {';
        
        while ($value = current($data)) {
            $key = key($data);
            echo $s2.$key.': '.$value.';' ;
            next($data);
        }
        
        echo $s1.'}';
        echo PHP_EOL;
    }

    
    public function style_data($name = NULL) {
        // body - normal - default
        $data = array('background-color' => 'transparent',
            'margin'            => '0px 0px 0px 0px',
            'border'            => '0px',
            'text-align'        => 'left',
            'font-family'       => 'Helvetica, Arial, sans-serif',
            'font-size'         => '13px',
            'font-weight'       => 'normal',
            'line-height'       => '27px',
            'color'             => 'black');
        

        if ($name == NULL) {
            return $data;
        }

        $name = trim($name);
        $name = strtolower($name);
        
        switch ($name) { 
            case 'a':
                $data['color']            = '#003366';
                $data['font-size']        = '13px';
                $data['font-weight']      = 'normal';
                $data['text-decoration']  = 'none';
                break;
            case 'a:hover':
                $data['color']            = 'red';
                $data['font-weight']      = 'bold';
                $data['font-size']        = '125%';
                $data['border-bottom']    = '1px';
                $data['text-decoration']  = 'underline';
                break;
            case 'emphasised':
                $data['color']            = '#C73504';
                $data['font-weight']      = 'bold';
                //$data['font-size']        = '12px';
                //$data['font-weight']      = 'bold';
                break;
            case 'hline':
                $data['color']            = 'white';
                $data['font-size']        = '23px';
                $data['font-weight']      = 'bold';
                $data['text-align']       = 'left';
                $data['line-height']      = '32px';
                break;
            case 'hmenu':
                $data['color']            = 'white';
                $data['font-size']        = '13px';
                $data['font-weight']      = 'normal';
                $data['text-align']       = 'right';
                break;
            case 'a.hlink':
                $data['color']            = '#9DF505'; //#F2F230';
                $data['font-size']        = '13px';
                $data['font-weight']      = 'normal';
                $data['text-align']       = 'right';                
                $data['text-decoration']  = 'none';
                break;
            case 'a.hlink:hover':
                $data['color']            = '#FA9F37';
                $data['font-size']        = '150%';
                $data['font-weight']      = 'bold';
                $data['text-align']       = 'right';                
                $data['text-decoration']  = 'underline';
                break;
            case 'p.emphasised':
                $data['color']            = '#C73504';
                break;
            case 'p.footer':
                $data['line-height']      = '32px';
                $data['padding']          = '0px 10px 0px 10px';
                $data['font-size']        = '11px';
                $data['color']            = '#505050';
                $data['text-align']       = 'center';
                break;
            case 'code':
                $data['background-color'] = '#F9F9F9';
                $data['margin']           = '14px 0px 14px 0px';
                $data['padding']          = '12px 10px 12px 10px';
                $data['color']            = '#002166';
                $data['font-size']        = '12px';
                $data['border']           = '1px solid #D0D0D0';
                $data['display']          = 'block';
                break;
            case 'input':
            
            	$data['background-color']  = '#faf8e3';
            	$data['font-size']         = '15px';
                $data['padding']           = '3px 6px 3px 6px';
                $data['color']             = '#4e6e17';
                $data['box-shadow']        = '0 0 0px';
                
            	break;
            	
            case 'input:hover':
            	$data['background-color']  = '#f8fecf';
            	break;
            case 'input.submit':
            	$data['font-size']         = '15px';
                $data['padding']           = '0px 0px 0px 0px';
                $data['text-align']        = 'center';
                $data['background-color']  = '#fafafa';
                $data['border']            = '1px solid #dddddd';
                $data['color']             = 'darkred';
                $data['width']             = '8em';
                $data['height']            = '2em';
                
            	break;
            case 'input[type=submit]:disbaled':
            	$data['font-size']         = '15px';
                $data['padding']           = '0px 0px 0px 0px';
                $data['text-align']        = 'center';
                $data['width']             = '8em';
                $data['height']            = '2em';
                $data['background']        = '#dddddd';
                $data['border']            = '1px solid #ababab';
                $data['color']             = '#909090';            	
            	break;
            case 'textarea':
            	$data['font-size']         = '15px';
                $data['padding']           = '6px 6px 6px 6px';
                $data['box-shadow']        = '0px 0px 1px';
          		break;  
            default:
                break;
        }
        /*
            box-shadow: 0 0 2px;
            background:  #07AA75;
            border:      1px solid #0F799E;

        */
        return $data;
    }
    
    
    // create and return inline style statement for html tag
    //      $data:   array of style's elements
    public function style_inline($data = NULL) {
        if ($data == NULL) {
            return '';
        }
            
        $vstr = ' style = "';
        $s1   = '';
        while ($value = current($data)) {
            $key  = key($data);
            $vstr = $vstr.$s1.$key.': '.$value;
            $s1   = '; ';
            next($data);
        }
        
        $vstr = $vstr.'"';
        return $vstr;
    }
    
    // echo line: add a $line into html document
    //     $line  : required, a line to be added
    //     $tagoff: != null -> add html tags < & >
    //     $inline: != null -> add into current line
    public function echo_line($line, $tagoff = NULL, $inline = NULL) {
        if ($inline == NULL) {
            echo PHP_EOL;
        }
        
        if ($tagoff == NULL) {
            echo '<'.$line.'>';
        } else {
            echo $line;
        }
    }
    
    
    public function add_totext($source, $added, $prefix='', $suffix='') {
        $text = $source;
        if (is_string($added)==true && strlen($added) > 0) {
            $text = $source.$prefix.$added.$suffix;
        }
        return $text;
    }

    
    // html request url 
    
    public function request_url_maker($url, $req, $params = NULL) {
        
        $url = trim($url);
        $req = trim($req);
        
        $req_url = $url;
        if ($this->check_suffix($req_url, '/') == FALSE) {
            $req_url = $req_url.'/';
        }
        
        $req_url = $req_url.$req;
        
        if ($params == NULL) {
            return $req_url;
        }
        
        if (is_array($params) == FALSE) {
            return $req_url;
        }
        
        if ($this->check_suffix($req_url, '?') == FALSE) {
            $req_url = $req_url.'?';
        }
        
        $s1 = '';
        while ($value = current($params)) {
            $key = key($params);
            $key = trim(strtolower($key));
            $req_url = $req_url.$s1.$key.'='.trim($value);
            $s1 = '&';
            next($params);
        }
        
        return $req_url;
    }
    
    
    public function check_prefix($source, $prefix) {
        
        if ($this->check_input_string($prefix) == FALSE) {
            return FALSE;
        } 
        
        $len = strlen($prefix);
        if ($len > strlen($source)) {
            return FALSE;
        }
        
        if ($prefix == substr($source, 0, $len)) {
            return TRUE;
        }
        
        return FALSE;
    }
    
    public function check_suffix($source, $suffix) {

        if ($this->check_input_string($suffix) == FALSE) {
            return FALSE;
        } 
        
        $len = strlen($suffix);
        if ($len > strlen($source)) {
            return FALSE;
        }
        
        $len = 0 - $len;
        if ($suffix == substr($source, $len)) {
            return TRUE;
        }
        
        return FALSE;
    }
    
    
    public function check_input_string($str) {
        if ($str == NULL) {
            return FALSE;
        }
        
        if (is_string($str) == FALSE ) {
            return FALSE;
        }
        
        if (strlen(trim($str)) == 0) {
            return FALSE;
        }
        
        return TRUE;
    }
    
    
    // html default;
    
    
    public function echoln($option = 'all', $value = ' ') {
    	$option = trim(strtolower($option));
        $s1 = PHP_EOL;
        $s2 = '    ';
        
        switch ($option) {
            case 'html':
                echo $s1.'<!DOCTYPE html>';                
                break;
            case 'head';
                echo $s1.'<html>'.$s1.'<head>';
                echo $s1.$s2.'<meta charset="utf-8">';
	            echo $s1.$s2.'<title>'.$value.'</title>';
                break;
            case 'style':
                echo $s1.$s2.'<style type="text/css">';
                break;
            case '/style':
                echo $s1.$s2.'</style>';
                break;
            case 'sp1':
                echo $s1.$sp2.$value;
                break;
            case 'sp2':
                echo $s1.$sp2.$sp2.$value;
                break;
            case 'body':
                echo $s1.'</head>';
                echo $s1.'<body>';
                break;
            case '/html':
                echo $s1.'</body>';
                echo $s1.'</html>';
                break;
            case 'simple-html':
                echo $s1.'<!DOCTYPE html>';
                echo $s1.'<html>';
                echo $s1.'<head>';
                echo $s1.$s2.'<title>simple html maker</title>';
                echo $s1.'</head>';
                echo $s1.'<body>';
                echo $c1.$s2.'<h1>This is simple html</h1>';
                echo $s1.'</body>';
                echo $s1.'</html>';                            
            	break;
            default:
                break;
        }
        
    }
    
    public function print_footer() {
    	/*
        <p class="footer">Page rendered in <strong>{elapsed_time}</strong> seconds. 
        <?php echo  (ENVIRONMENT === 'development') ?  'CodeIgniter Version <strong>'.CI_VERSION.'</strong>' : '' ?></p>
		*/
		echo '<p class="footer">'.tb_msg('common','page.rendered').' <b>{elapse_time}</b> s. ';
		echo '(ENVIRONMENT === "development") ?  "CodeIgniter Version <strong>".CI_VERSION."</strong> : "'.tb_msg('common','eshop.version');
		echo '</p>';
    }
}