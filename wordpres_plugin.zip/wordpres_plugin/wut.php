<?php
/**
 * @package WUT
 * @version 1.0.0
 */
/*
Plugin Name: WUT
Plugin URI: https://sacalabob.com
Description: hehehe
Author: Dinh
Version: 1.0.0
Author URI: https://sacalabob.com
*/

function wut(){
    include_once('wut_contacts.php');
}

function wut_shortcode(){
    ob_start();
    wut();
    return ob_get_clean();

}

add_shortcode( 'wut', 'wut_shortcode' );

function safe_post($var){
    if (isset($_POST[$var])){
      return $_POST[$var];
    }
    else{
      return '';
    }
}
