<?php
	if (ktk_check_token($token) != 0) {
		return;
	}

    $class = 'admin';
	$wuser = new my_user();
	$data  = array();
	$data['token'] = $token;
	$data['id']    = $user_id;
	$data['name']  = $user_name;
	$roles = $cat->roles_data();
	$wuser->load_user($data);

	echo '<form  action="' . tb_uri('user_roles') . '" method="post">';
	echo '<input type="hidden" name="uid"   value="'.$wuser->user_id.'">';
	echo '<input type="hidden" name="uname" value="'.$wuser->user_name.'">';

?>

<script>
	function tbwidth() {
		var dv = document.getElementById("tbl");
		var sd = window.screen.width;
		var w = "100%";
		if (sd > 1000) {
			w = "80%";
		}
		dv.style.width = w;
	}
</script>

<div id="tbl" class="table" type="update" text-align="center">

	<div class="row" type="title-center"><?php echo '['.$wuser->user_name.' - '.$wuser->full_name.']'; ?></div>
	<div class="row" type="update">
		<div class="col-sm-2"  type="th"><?php echo tb_word('yes'); ?></div>
		<div class="col-sm-10" type="th" style="text-align: left"><?php echo tb_word('roles'); ?></div>
	</div>

<?php 

	$str1 = '<input type="checkbox" name="checks[]" value="';
	$str2 = '"';
	$str3 = '>';

	if (is_array($roles)==true) {
		foreach ($roles as $key=>$value) {
			$checked = ($wuser->role_check($key)) ? ' checked' : '';
			$prefix  = substr($key,0,2);
			$k1 = $key;
			if ($prefix === '__') {
				$k1 = substr($key,2, strlen($key)-2);
			}

			$str_title = tb_title($k1);
			$str_check = $str1.$key.$str2.$checked.$str3;
			$str_pad   = ($prefix==='__') ? '' : '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';

			$s1 = PHP_EOL.' ';
			
			echo PHP_EOL.'<div class="row" type="update">';
			echo $s1.'<div class="col-sm-2" type="alt" style="text-align: center">'.$str_check.'</div>';
			if ($prefix==='__') {
				echo $s1. '<div class="col-sm-10" type="odd">' .$str_title.'</div>';
			} else {
				echo $s1.'<div class="col-sm-10" type="td">' .$str_pad.$str_title.'</div>';
			}
			echo '</div>';
		
		}
	}
        
?>
	<div class="row" type="update" style="border-bottom: 0px">
		<input type="submit" class="submit" name="btnSave"   value="Save">
		<input type="submit" class="submit" name="btnCancel" value="Cancel">
	</div>
</div>
</form>
<script>
	tbwidth();
</script>
